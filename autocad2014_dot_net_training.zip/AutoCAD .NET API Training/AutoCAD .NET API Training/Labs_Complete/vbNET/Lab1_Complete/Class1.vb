﻿Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Runtime


Public Class Class1

    <CommandMethod("HelloWorld")> _
    Public Sub HelloWorld()
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        ed.WriteMessage("Hello World")

    End Sub

End Class


