Welcome to the AutoCAD .NET API Training

Lab steps:
The Labs can be done in two ways. One is to copy the steps from the Lab documents
into a Visual Studio project that you create. The other way is to use the provided
projects that already have the lab steps. The exception to this is Lab1. In this 
Lab you need to create a new project. 

Lab Documents:
The lab documents are in these locations( either C# or VB.NEt)
..\AutoCAD .NET Training\Labs\cSharp\Lab Documents
..\AutoCAD .NET Training\Labs\vbNet\Lab Documents
In these directories there are two directories VS_2008 and VS_2010. 

Lab Projects:
The Lab projects are in these directories:
..\AutoCAD .NET Training\Labs\cSharp
..\AutoCAD .NET Training\Labs\vbNet
In each of the Lab directories you will find sln files for both Visual Studio 2010 and 2008.
If you are using AutoCAD 2011, then you must use the Visual Studio 2008 solution.
If you are using AutoCAD 2012 / AutoCAD 2013, then must use the Visual Studio 2010 solution.

  
Completed Lab projects.
If you get stuck on something you can refer to the completed labs. 
..\AutoCAD .NET Training\Labs_Complete\cSharp
..\AutoCAD .NET Training\Labs_Complete\vbNET

PowerPoint presentation.
The AutoCAD .NET Training.pptx is used when we deliver the live training. It may be useful
as you go through the training to see the slides.


Thanks for taking this AutoCAD .NET API training.