﻿' (C) Copyright 2010 by Autodesk, Inc. 
'
Imports System
Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.EditorInput

' This line is not mandatory, but improves loading performances
<Assembly: CommandClass(GetType(Lab2.MyCommands))> 

Namespace Lab2

    ' This class is instantiated by AutoCAD for each document when
    ' a command is called by the user the first time in the context
    ' of a given document. In other words, non static data in this class
    ' is implicitly per-document!
    Public Class MyCommands

        ' The CommandMethod attribute can be applied to any public  member 
        ' function of any public class.
        ' The function should take no arguments and return nothing.
        ' If the method is an instance member then the enclosing class is 
        ' instantiated for each document. If the member is a static member then
        ' the enclosing class is NOT instantiated.
        '
        ' NOTE: CommandMethod has overloads where you can provide helpid and
        ' context menu.

        ' Modal Command with localized name
        ' AutoCAD will search for a resource string with Id "MyCommandLocal" in the 
        ' same namespace as this command class. 
        ' If a resource string is not found, then the string "MyLocalCommand" is used 
        ' as the localized command name.
        ' To view/edit the resx file defining the resource strings for this command, 
        ' * click the 'Show All Files' button in the Solution Explorer;
        ' * expand the tree node for myCommands.vb;
        ' * and double click on myCommands.resx
        <CommandMethod("MyGroup", "MyCommand", "MyCommandLocal", CommandFlags.Modal)> _
        Public Sub MyCommand() ' This method can have any name
            ' Put your command code here
        End Sub

        ' Modal Command with pickfirst selection
        <CommandMethod("MyGroup", "MyPickFirst", "MyPickFirstLocal", CommandFlags.Modal + CommandFlags.UsePickSet)> _
        Public Sub MyPickFirst() ' This method can have any name
            Dim result As PromptSelectionResult = Application.DocumentManager.MdiActiveDocument.Editor.GetSelection()
            If (result.Status = PromptStatus.OK) Then
                ' There are selected entities
                ' Put your command using pickfirst set code here
            Else
                ' There are no selected entities
                ' Put your command code here
            End If
        End Sub

        ' Application Session Command with localized name
        <CommandMethod("MyGroup", "MySessionCmd", "MySessionCmdLocal", CommandFlags.Modal + CommandFlags.Session)> _
        Public Sub MySessionCmd() ' This method can have any name
            ' Put your command code here
        End Sub

        ' Start of Lab2

        ' 1. Add a command named addAnEnt. Use the CommandMethod attribute and a 
        ' Public Sub. (use the line continuation character " _")
        ' Note: put the End Sub after step 19.

        ' 2. Declare an Editor variable named ed. Instantiate it using the
        ' Editor property of the Application.DocumentManager.MdiActiveDocument

        ' 3. Declare a PromptKeywordOptions variable and instantiate it by creating 
        ' a New PromptKeywordOptions. Use a string similar to the following for the 
        ' messageAndKeywords string.
        '"Which entity do you want to create? [Circle/Block] : ", "Circle Block"

        ' 4. Declare a PromptResult. Use the GetKeywords method of the Editor  variable
        ' created in step 1. Pass in the PromptKeywordOptions created in step 2.
        ' Instantiate the PromptResult by making it equal to the return value of 
        'the GetKeywords method.

        ' 5. Add an If Then statement that tests the Status of the PromptResult 
        'created in step 4. Use the PromptStatus enum for the test. (see if it 
        'is equal to PromptStatus.OK) Note. Move the End If statement after step 19. 


        ' 6. PromptStatus was ok. Now create a Select Case. For the case use the
        ' StringResult property of the PromptResult variable used above
        ' Note: Move the End Select after step 19.
        ' (Before the End If)

        ' 7. Use "Circle" for the Case. (if the StringResult is "Circle")
        ' (In step 15 we will add the case for "Block").

        ' 8. We want to ask the user for the center of the circle. Declare
        ' a PromptPointOptions variable and instatiate it by making it equal
        ' to a New PromptPointOptions. Use "Pick Center Point : " for message 
        ' parameter()

        ' 9. Declare a PromptPointResult variable. Use the GetPoint method of
        ' the Editor created in step 2. (Pass in the PromptPointOptions created 
        ' in step 8). Instantiate the PromptPointResult by making it equal to the 
        ' return of the GetPoint method.

        ' 10. Add an If Then statement that tests the Status of the PromptPointResult 
        ' created in step 9. Use the PromptStatus enum for the test. 
        ' (make sure it is OK)
        ' Note: Move the End If statement right before step 15. 


        ' 11. Now we want to ask the user for the radius of the circle. Declare
        ' a PromptDistanceOptions variable. Instatiate it by making it equal
        ' to a New PromptDistanceOptions. 
        ' Use "Pick Radius : " for the message parameter. 

        ' 12.  We want to use the point selected in step 9 as the 
        ' base point for the GetDistance call coming up. To do this use
        ' the BasePoint property of the PromptDistanceOptions variable created
        ' in the previous step. Make the BasePoint equal to the Value property
        ' of the PromptPointResult created in step 9. 


        ' 13. We need to tell the input mechanism to actually use the basepoint.
        ' Do this by setting the UseBasePoint property of the 
        ' PromptDistanceOptions created in step 11 to True. 


        ' 14. Get the radius for the circle. Declare a PromptDoubleResult variable.
        ' Instantiate it using the GetDistance method of the Editor variable created
        ' in step 2. Pass in the PromptDistanceOptions created in step 11 and 
        ' modified in the previous steps. 

        ' 15. Add the Case for the "Block


        ' 16. Now we want to ask the user for the name of the block. Declare
        ' a PromptStringOptions varable and instatiate it by creating a new
        ' PromptStringOptions. Use "Enter name of the Block to create : " for
        ' the message parameter.

        ' 17. No spaces are allowed in a blockname so disable it. Do this by setting
        ' the AllowSpaces property of the PromptStringOptions created in step 16
        ' to False.

        ' 18. Get the name the user entered. Declare a PromptResult variable
        ' and instantiate it using the GetString method of the Editor object
        ' created in step 2. Pass in the PromptStringOptions created in step 16.

        ' 19. Build the project. Place a break point. Use the NETLOAD command
        ' and run the AddAnEnt command. Step through the code and fix any errors.
        ' Remember to run the command and test the code for both circle and block.
        ' End of Lab2





        ' LispFunction is similar to CommandMethod but it creates a lisp 
        ' callable function. Many return types are supported not just string
        ' or integer.
        <LispFunction("MyLispFunction", "MyLispFunctionLocal")> _
        Public Function MyLispFunction(ByVal args As ResultBuffer) ' This method can have any name
            ' Put your command code here

            ' Return a value to the AutoCAD Lisp Interpreter
            Return 1
        End Function

    End Class

End Namespace