﻿' (C) Copyright 2002-2005 by Autodesk, Inc. 
'
' Permission to use, copy, modify, and distribute this software in
' object code form for any purpose and without fee is hereby granted, 
' provided that the above copyright notice appears in all copies and 
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting 
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
'
' Use, duplication, or disclosure by the U.S. Government is subject to 
' restrictions set forth in FAR 52.227-19 (Commercial Computer
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
' (Rights in Technical Data and Computer Software), as applicable.
'



Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Geometry
Imports System.Windows

Imports Autodesk.AutoCAD.Windows
Imports System.Runtime.InteropServices

' Beginning of Lab8
' To perform load-time initialization, an AutoCAD .NET application can
' implement a specific class to allow this.  A class need only implement 
' the IExtensionApplication .NET interface, and expose an assembly-level 
' attribute which specifies this class as the ExtensionApplication.  
' The class can then respond to one-time load and unload events. 
' In this lab we will add a context menu and add a tab to the Options dialog 
' We will also enable Drag & Drop to run a command when a label is dragged 
' and dropped on the AutoCAD drawing window.

<Assembly: ExtensionApplication(GetType(adskClass))> 

Public Class adskClass
    Implements IExtensionApplication

    ' 1. Modify the asdkClass1 class to implement the IExtensionApplication interface. 
    ' Note: Visual Studio Automatically adds a couple of required methods
    ' Initialize() and Terminate. Look for these methods below the other existing methods.
    ' Copy and paste so steps 23 and 37 are inside the Initialize procedure and step 24
    ' is inside the Terminate procedure
    ' Also add this attribute by uncommented the next line of code. (needs to be oustide of the class)
    '' This line is not mandatory, but improves loading performances
    ' <Assembly: ExtensionApplication(GetType(adskClass))> 

    ' 2. Declare a member variable as ContextMenuExtension. It will be instantiated
    ' in step 6
    ' (This class is a member of the Autodesk.AutoCAD.Windows namespace).
    Dim myContextMenu As ContextMenuExtension

    ' 3. Create a private procedure named AddContextMenu.
    ' Note: Put the End Sub after step 12.
    Private Sub AddContextMenu()

        ' 4. Declare an editor variable. Instantiate it by making it equal to the 
        ' Editor property of the Application.DocumentManager.MdiActiveDocument.Editor
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor

        ' 5. Add a Try Catch block. 
        ' Note: put the Catch below step 11. Have the catch use an
        ' Application.Exception name it "ex"
        ' Put the End Try below step 12.
        Try
            ' 6. Make the ContextMenuExtension declared in step 2 equal 
            ' to a New ContextMenuExtension
            myContextMenu = New ContextMenuExtension()

            ' 7. Make the Title property of the ContextMenuExtension 
            ' instantiated in step 7 equal to "Circle Jig". (it is going
            ' to run the command completed in Lab2.
            myContextMenu.Title = "Circle Jig"

            ' 8. Declare a MenuItem variable named mi. Instantiate by 
            ' making it eaual to a New MenuItem. For the string parameter
            ' use a string like "Run Circle Jig".
            Dim mi As MenuItem = New MenuItem("Run Circle Jig")

            ' 9. The way the Context menu works is that for each menu entry, we specify a 
            ' specific member function to be called handling the menu-clicked event. 
            ' Use the VB keyword AddHandler and AddressOf to specify that we want 
            ' the event handled by one of our functions. For the object paramater
            ' use the Click event of the MenuItem created in step 8. For the delegate
            ' parameter use a function we will create in step 20 named CallbackOnClick.
            AddHandler mi.Click, AddressOf CallbackOnClick

            ' 10. Use the Add method of the MenuItems collection of the 
            ' ContextMenuExtension instantiated in step 6. Pass in the 
            ' MenuItem created in step 8.
            myContextMenu.MenuItems.Add(mi)

            ' 11. Use the AddDefaultContextMenuExtension of the Application.
            ' Pass in the ContextMenuExtension
            Application.AddDefaultContextMenuExtension(myContextMenu)

        Catch ex As ApplicationException
            ' 12. Use the editor variable created in step 4 and write a message.
            ' to the command line Something like"
            ' "Error Adding Context Menu: " + ex.Message
            ed.WriteMessage("Error Adding Context Menu: " + ex.Message)
        End Try
    End Sub

    ' 13. Create a procedure named RemoveContextMenu.
    ' Note: Put the End Sub after step 19.
    Sub RemoveContextMenu()

        '14. Declare an document variable. Instantiate it by making it 
        '    equal the MdiActiveDocument 
        Dim activeDoc As Document
        activeDoc = Application.DocumentManager.MdiActiveDocument

        ' 15. Add a Try Catch block. 
        ' Note: put the Catch below step 18. Have the catch use an
        ' Application.Exception name it "ex"
        ' Put the End Try below step 19.
        Try
            ' 16. Use an "If Then" statement and test if the ContextMenuExtension
            ' declared in step 2 is nothing (Not Is  Nothing).
            ' Note: put the "End If" below step 18
            If Not myContextMenu Is Nothing Then
                ' 17. In the if statement, use RemoveDefaultContextMenuExtension
                ' of the Application. Pass in the ContextMenuExtension declared
                ' in step 2
                Application.RemoveDefaultContextMenuExtension(myContextMenu)
                ' 18. Make the ContextMenuExtension declared in step 2 equal to nothing
                myContextMenu = Nothing
            End If

        Catch ex As ApplicationException
            ' Use an "If Then" statement and test if the activeDoc
            ' declared in step 14 is nothing (Not Is  Nothing).
            ' In AutoCAD 2013, If AutoCAD is being closed, we may not have access to the active document here.
            'If Not activeDoc Is Nothing Then
            ' 19. Use the editor property of the active document and write a message. Something like 
            ' "Error Removing Context Menu: " + ex.Message 
            activeDoc.Editor.WriteMessage("Error Removing Context Menu: " + ex.Message)
            'End If
        End Try
    End Sub

    ' 20. Create a procedure named CallbackOnClick. This is the method that
    ' will be called when the Menu Item is clicked. Set in step 9.
    ' Note: Put the End Sub after step 22.
    Private Sub CallbackOnClick(ByVal Sender As Object, ByVal e As System.EventArgs)
        ' 21. Use the using statement and create a variable as a DcoumentLock. 
        ' Instantiate it by making it equal to the .MdiActiveDocument.LockDocument
        ' method. (Because this event is running outside of the Document context we
        ' need to lock the document). By design, AutoCAD’s data is stored in documents,
        ' where commands that access entities within them have rights to make 
        ' modifications.  When we run our code in response to a context-menu click, 
        ' we are accessing the document from outside the command structure. 
        ' In order to unlock the document we simply dispose DocumentLock object 
        ' returned on the original lock request.
        ' Note: put the End Using statement after step 22.
        Using docLock As DocumentLock = Application.DocumentManager.MdiActiveDocument.LockDocument()
            ' 22. Call the CircleJig() function.
            CircleJig()
            ' Added from step 25
            If is64bits Then
                acedPostCommand64("CANCELCMD")
            Else
                acedPostCommand32("CANCELCMD")
            End If
        End Using
    End Sub


    Public Sub Initialize() Implements Autodesk.AutoCAD.Runtime.IExtensionApplication.Initialize
        ' 23. Inside the Initialize procedure. (created by Visual Studio in step 1) add
        ' a call to AddContextMenu(). This will add the Context menu when this .NET dll
        ' is loaded.
        ' Note: Proceed to step 24 below
        AddContextMenu()

        ' 37. Inside the Initialize procedure. Uncomment this line after doing 
        ' steps through 24 - 27
        ' This will run this function when the dll is loaded in AutoCAD
        AddTabDialog()

    End Sub

    Public Sub Terminate() Implements Autodesk.AutoCAD.Runtime.IExtensionApplication.Terminate
        ' 24. Inside the Terminate procedure. (created by Visual Studio in step 1) add
        ' a call to RemoveContextMenu(). This will remove the Context menu when this .NET dll
        ' is unloaded. Before proceding to step 25 build and netload the dll. Right click
        ' on the ModelSpace background. You should see the new MenuItem. "Circle Jig"
        RemoveContextMenu()
    End Sub



    ' 25. Uncomment this to fix behavior where command line
    ' is not automatically set back to normal command after running 
    ' the MenuItem. 
    ' Imports System.Runtime.InteropServices '(move outside of the class needed for P/Invoke)
    ' acedPostCommand32("CANCELCMD") ' Move this after CircleJig() in step 22
#If ACAD2012 OrElse ACAD2011 Then
        <DllImport("acad.exe", CallingConvention:=CallingConvention.Cdecl, CharSet := CharSet.Unicode, EntryPoint := "?acedPostCommand@@YAHPB_W@Z")> _
        Public Shared Function acedPostCommand32(cmd As String) As Boolean
        End Function

        <DllImport("acad.exe", CallingConvention:=CallingConvention.Cdecl, CharSet := CharSet.Unicode, EntryPoint := "?acedPostCommand@@YAHPEB_W@Z")> _
        Public Shared Function acedPostCommand64(cmd As String) As Boolean
        End Function
#End If

#If ACAD2013 OrElse ACAD2014 Then
    <DllImport("accore.dll", CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Unicode, EntryPoint:="?acedPostCommand@@YAHPB_W@Z")> _
    Public Shared Function acedPostCommand32(ByVal cmd As String) As Boolean
    End Function

    <DllImport("accore.dll", CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Unicode, EntryPoint:="?acedPostCommand@@YAHPEB_W@Z")> _
    Public Shared Function acedPostCommand64(ByVal cmd As String) As Boolean
    End Function
#End If

#If ACAD2015 Then
    <DllImport("accore.dll", CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Unicode, EntryPoint:="?acedPostCommand@@YAHPB_W@Z")> _
    Public Shared Function acedPostCommand32(ByVal cmd As String) As Boolean
    End Function

    <DllImport("accore.dll", CallingConvention:=CallingConvention.Cdecl, CharSet:=CharSet.Unicode, EntryPoint:="?acedPostCommand@@YAHPEB_W@Z")> _
    Public Shared Function acedPostCommand64(ByVal cmd As String) As Boolean
    End Function
#End If

    'check the OS (32 or 64 bits)
    Public Shared ReadOnly Property is64bits() As Boolean
        Get
            Return (Application.GetSystemVariable("PLATFORM").ToString().IndexOf("64") > 0)
        End Get
    End Property


    ' Lab8 Steps 26 - 37. Add a tab to the Options dialog.
    ' To add a tab you need to subscribe to notifications when the options dialog
    ' is launched. This is done by passing the address of a member function to be called.  
    ' You will also need to implement the callback function; the second argument
    ' passed into the callback is a ‘TabbedDialogEventArgs’ object which we must 
    ' use to call its ‘AddTab’ member. AddTab takes a title string, and an instance
    ' of a ‘TabbedDialogExtension’ object, which wraps our form.  Within the constructor
    ' of TabbedDialogExtension, we pass a new instance of our form, and callback 
    ' addresses we can pass to handle either OnOK, OnCancel or OnHelp.

    ' 26. First Declare a Public Shared variable as a String. This variable will be set
    ' from our custom tab in the Options dialog. Name it something like "myVariable"  
    Public Shared myVariable As String = String.Empty

    ' 27. Add a Publc Shared procedure called AddTabDialog. We will call this procedure
    ' from the Initialize() Sub that was created in step 1
    ' Note: Put the End Sub after step 28.
    Public Shared Sub AddTabDialog()

        ' 28. Use the AddHandler statement to had a Application DisplayingOptionDialog
        ' event. Use the DisplayingOptionDialog event of the Application class 
        ' for the first parameter. For the second parameter (Delegate) use the 
        ' AddressOf statement and the name of the procedure you will create in 
        ' step 29. (name it TabHandler)
        AddHandler Application.DisplayingOptionDialog, AddressOf TabHandler

    End Sub

    ' 29. Create a Private Shared Sub named TabHandler. This is the Sub that 
    ' will be called when the Options dialog is displayed. (The name needs to be
    ' the name used in the Delegate parameter of step 28). The first parameter is an 
    ' object. (Use ByVal and sender as the name of the Object). 
    ' The second parameter is a TabbedDialogEventArgs. 
    ' (Use ByVal e As Autodesk.AutoCAD.ApplicationServices.TabbedDialogEventArgs)
    ' Note: Put the End Sub after step 33

    Private Shared Sub TabHandler(ByVal sender As Object, ByVal e As Autodesk.AutoCAD.ApplicationServices.TabbedDialogEventArgs)

        ' 30. Declare a variable as the user control that we are going to add to
        ' the Options dialog. (myCustomTab) Use the New keyword to instantiate it. 
        Dim myCustomTab As myCustomTab = New myCustomTab()

        ' 31. Delcare a variable as a TabbedDialogAction. Instantiate it using the New statement
        ' to create a new TabbedDialogAction for the parameter using AddressOf and the 
        ' OnOk method of the User control variable from step 29. We can subscribe to, Ok, 
        ' Cancel and Help.  In this example, we chose to handle only OK.
        ' Note: The OnOk method will be added in Steps 35 - 36. (You can skip forward to these steps
        ' in the code window for the user form - myCustomTab - come back here of course)
        Dim tabbedDialogAct As TabbedDialogAction = New TabbedDialogAction(AddressOf myCustomTab.OnOk)

        ' 32. Declare a variable as a TabbedDialogExtension. Instantiate it using the New statement
        ' to create a new TabbedDialogExtension for the control parameter pass in the User control variable 
        ' from step 30. and the TabbedDialogAction pass in the variable from step 31.
        Dim tabbedDialogExt As TabbedDialogExtension = New TabbedDialogExtension(myCustomTab, tabbedDialogAct)

        ' 33. Use the AddTab method of the TabbedDialogEventArgs passed into the event.
        ' (named e). For the Name parameter use something like  "Value for custom variable". For the 
        ' TabbedDialogExtension parameter use the TabbedDialogExtension from step 32.
        ' Note: Proceed to step 34 in the TestTab function below.
        e.AddTab("Value for custom variable", tabbedDialogExt)

    End Sub

    ' Run this command to get the value set from
    <CommandMethod("testTab")> _
    Public Sub TestTab()
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        ' 34. Uncomment this line to print the value set from the Tab added in the previous
        ' steps to the command line. 
        ' Note: You may need to change myVariable to the name you used in step 26
        ' Proceed to steps 35 - 36 in the Code window for the UserControl. (myCustomTab)
        ' if you have not already done so. Also do step 37, close to step 23
        ed.WriteMessage(myVariable.ToString())

        ' After steps 35-36 are complete Build, Load and run the AutoCAD OPTIONS to see 
        ' the custom dialog. Set the value in the text box click Ok and then run 
        ' this command you should see the value set in the Options dialog printed 
        ' on the command line.
        ' After this proceed to steps 38-46 in the code
        ' window for UserControl1. (Adds functionality for Drag & Drop).
    End Sub


    ' Define command 'helloworld'
    <CommandMethod("helloworld")> _
    Public Sub helloworld()

        ' get the editor object
        Dim ed As Autodesk.AutoCAD.EditorInput.Editor = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor
        ' now write to the command line
        ed.WriteMessage(vbCr + "Hello World")

    End Sub

    <CommandMethod("addAnEnt")> _
    Public Shared Sub AddAnEnt()

        ' get the editor object so we can carry out some input
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor

        ' first decide what type of entity we want to create
        Dim getWhichEntityOptions As PromptKeywordOptions = New PromptKeywordOptions("Which entity do you want to create? [Circle/Block] : ", "Circle Block")
        ' now input it
        Dim getWhichEntityResult As PromptResult = ed.GetKeywords(getWhichEntityOptions)
        ' if ok
        If (getWhichEntityResult.Status = PromptStatus.OK) Then

            ' test which one is required
            Select Case getWhichEntityResult.StringResult

                Case "Circle"

                    ' pick the center point of the circle
                    Dim getPointOptions As PromptPointOptions = New PromptPointOptions("Pick Center Point : ")
                    Dim getPointResult As PromptPointResult = ed.GetPoint(getPointOptions)
                    ' if ok
                    If (getPointResult.Status = PromptStatus.OK) Then

                        ' the get the radius
                        Dim getRadiusOptions As PromptDistanceOptions = New PromptDistanceOptions("Pick Radius : ")
                        ' set the start point to the center (the point we just picked)
                        getRadiusOptions.BasePoint = getPointResult.Value
                        ' now tell the input mechanism to actually use the basepoint!
                        getRadiusOptions.UseBasePoint = True
                        ' now get the radius
                        Dim getRadiusResult As PromptDoubleResult = ed.GetDistance(getRadiusOptions)
                        ' if all is ok
                        If (getRadiusResult.Status = PromptStatus.OK) Then

                            ' need to add the circle to the current space
                            ' get the current working database
                            Dim dwg As Database = ed.Document.Database
                            ' now start a transaction
                            Dim trans As Transaction = dwg.TransactionManager.StartTransaction()
                            Try

                                ' create a new circle
                                Dim circle As New Circle(getPointResult.Value, Vector3d.ZAxis, getRadiusResult.Value)
                                ' open the current space (block table record) for write
                                Dim btr As BlockTableRecord = trans.GetObject(dwg.CurrentSpaceId, OpenMode.ForWrite)
                                ' now the circle to the current space, model space more than likely
                                btr.AppendEntity(circle)
                                ' tell the transaction about the new circle so that it can autoclose it
                                trans.AddNewlyCreatedDBObject(circle, True)
                                ' now commit the transaction
                                trans.Commit()

                            Catch ex As Exception
                                ' ok so we have an exception
                                ed.WriteMessage("problem due to " + ex.Message)
                            Finally
                                ' all done, whether an error on not - dispose the transaction.
                                trans.Dispose()
                            End Try

                        End If
                    End If

                Case "Block"

                    ' enter the name of the block
                    Dim blockNameOptions As PromptStringOptions = New PromptStringOptions("Enter name of the Block to create : ")
                    ' no spaces are allowed in a blockname so disable it
                    blockNameOptions.AllowSpaces = False
                    ' get the name
                    Dim blockNameResult As PromptResult = ed.GetString(blockNameOptions)
                    ' if ok
                    If (blockNameResult.Status = PromptStatus.OK) Then

                        ' lets create the block definition
                        ' get the current drawing
                        Dim dwg As Database = ed.Document.Database
                        ' now start a transaction
                        Dim trans As Transaction = dwg.TransactionManager.StartTransaction
                        Try

                            ' create the new block definition
                            Dim newBlockDef As BlockTableRecord = New BlockTableRecord
                            ' name the block definition
                            newBlockDef.Name = blockNameResult.StringResult

                            ' now add the new block defintion to the block table
                            ' open the blok table for read so we can check to see if the name already exists
                            Dim blockTable As BlockTable = trans.GetObject(dwg.BlockTableId, OpenMode.ForRead)
                            ' check to see if the block already exists
                            If (blockTable.Has(blockNameResult.StringResult) = False) Then
                                ' if it's not there, then we are ok to add it
                                ' but first we need to upgrade the open to write
                                blockTable.UpgradeOpen()
                                blockTable.Add(newBlockDef)
                                ' tell the transaction manager about the new object so that the transaction will autoclose it
                                trans.AddNewlyCreatedDBObject(newBlockDef, True)
                            End If

                            ' now add some objects to the block definition
                            Dim circle1 As New Circle(New Point3d(0, 0, 0), Vector3d.ZAxis, 10)
                            Dim circle2 As New Circle(New Point3d(20, 10, 0), Vector3d.ZAxis, 10)
                            Dim circle3 As New Circle(New Point3d(40, 20, 0), Vector3d.ZAxis, 10)
                            Dim circle4 As New Circle(New Point3d(60, 30, 0), Vector3d.ZAxis, 10)
                            Dim circle5 As New Circle(New Point3d(80, 40, 0), Vector3d.ZAxis, 10)
                            newBlockDef.AppendEntity(circle1)
                            newBlockDef.AppendEntity(circle2)
                            newBlockDef.AppendEntity(circle3)
                            newBlockDef.AppendEntity(circle4)
                            newBlockDef.AppendEntity(circle5)
                            ' tell the transaction manager about the new objects so that the transaction will autoclose it
                            trans.AddNewlyCreatedDBObject(circle1, True)
                            trans.AddNewlyCreatedDBObject(circle2, True)
                            trans.AddNewlyCreatedDBObject(circle3, True)
                            trans.AddNewlyCreatedDBObject(circle4, True)
                            trans.AddNewlyCreatedDBObject(circle5, True)

                            ' now set where it should appear in the current space
                            Dim blockRefPointOptions As PromptPointOptions = New PromptPointOptions("Pick insertion point of Block : ")
                            Dim blockRefPointResult As PromptPointResult = ed.GetPoint(blockRefPointOptions)
                            ' check to see if everything was ok - if not
                            If (blockRefPointResult.Status <> PromptStatus.OK) Then
                                ' dispose of everything that we have done so far and return
                                trans.Dispose()
                                Return
                            End If
                            ' now we have the block defintion in place and the position we need to create the reference to it
                            Dim blockRef As BlockReference = New BlockReference(blockRefPointResult.Value, newBlockDef.ObjectId)
                            ' otherwise add it to the current space, first open the current space for write
                            Dim curSpace As BlockTableRecord = trans.GetObject(dwg.CurrentSpaceId, OpenMode.ForWrite)
                            ' now add the block reference to it
                            curSpace.AppendEntity(blockRef)
                            ' remember to tell the transaction about the new block reference so that the transaction can autoclose it
                            trans.AddNewlyCreatedDBObject(blockRef, True)

                            ' all ok, commit it
                            trans.Commit()

                        Catch ex As Exception
                            ' a problem occured, lets print it
                            ed.WriteMessage("a problem occured because " + ex.Message)
                        Finally
                            ' whatever happens we must dispose the transaction
                            trans.Dispose()

                        End Try

                    End If

            End Select
        End If

    End Sub

    ' declare a paletteset object, this will only be created once
    Public myPaletteSet As Autodesk.AutoCAD.Windows.PaletteSet
    ' we need a palette which will be housed by the paletteSet
    Public myPalette As UserControl1

    ' palette command
    <CommandMethod("palette")> _
    Public Sub palette()

        ' check to see if it is valid
        If (myPaletteSet = Nothing) Then
            ' create a new palette set, with a unique guid
            myPaletteSet = New Autodesk.AutoCAD.Windows.PaletteSet("My Palette", New Guid("D61D0875-A507-4b73-8B5F-9266BEACD596"))
            ' now create a palette inside, this has our tree control
            myPalette = New UserControl1
            ' now add the palette to the paletteset
            myPaletteSet.Add("Palette1", myPalette)

        End If

        ' now display the paletteset
        myPaletteSet.Visible = True

    End Sub

    <CommandMethod("addDBEvents")> _
    Public Sub addDBEvents()

        ' the palette needs to be created for this
        If myPalette Is Nothing Then
            ' get the editor object
            Dim ed As Autodesk.AutoCAD.EditorInput.Editor = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor
            ' now write to the command line
            ed.WriteMessage(vbCr + "Please call the 'palette' command first")
            Exit Sub
        End If

        ' get the current working database
        Dim curDwg As Database = Application.DocumentManager.MdiActiveDocument.Database
        ' add a handlers for what we need
        AddHandler curDwg.ObjectAppended, New ObjectEventHandler(AddressOf callback_ObjectAppended)
        AddHandler curDwg.ObjectErased, New ObjectErasedEventHandler(AddressOf callback_ObjectErased)
        AddHandler curDwg.ObjectReappended, New ObjectEventHandler(AddressOf callback_ObjectReappended)
        AddHandler curDwg.ObjectUnappended, New ObjectEventHandler(AddressOf callback_ObjectUnappended)

    End Sub

    Private Sub callback_ObjectAppended(ByVal sender As Object, ByVal e As ObjectEventArgs)

        ' add the class name of the object to the tree view
        Dim newNode As System.Windows.Forms.TreeNode = myPalette.TreeView1.Nodes.Add(e.DBObject.GetType().ToString())
        ' we need to record its id for recognition later
        newNode.Tag = e.DBObject.ObjectId.ToString()

    End Sub

    Private Sub callback_ObjectErased(ByVal sender As Object, ByVal e As ObjectErasedEventArgs)

        ' if the object was erased
        If e.Erased Then
            ' find the object in the treeview control so we can remove it
            For Each node As Forms.TreeNode In myPalette.TreeView1.Nodes
                ' is this the one we want
                If (node.Tag = e.DBObject.ObjectId.ToString) Then
                    node.Remove()
                    Exit For
                End If
            Next
            ' if the object was unerased
        Else
            ' add the class name of the object to the tree view
            Dim newNode As System.Windows.Forms.TreeNode = myPalette.TreeView1.Nodes.Add(e.DBObject.GetType().ToString())
            ' we need to record its id for recognition later
            newNode.Tag = e.DBObject.ObjectId.ToString()
        End If
    End Sub
    Private Sub callback_ObjectReappended(ByVal sender As Object, ByVal e As ObjectEventArgs)

        ' add the class name of the object to the tree view
        Dim newNode As Forms.TreeNode = myPalette.TreeView1.Nodes.Add(e.DBObject.GetType().ToString())
        ' we need to record its id for recognition later
        newNode.Tag = e.DBObject.ObjectId.ToString()

    End Sub

    Private Sub callback_ObjectUnappended(ByVal sender As Object, ByVal e As ObjectEventArgs)

        ' find the object in the treeview control so we can remove it
        For Each node As Forms.TreeNode In myPalette.TreeView1.Nodes
            ' is this the one we want
            If (node.Tag = e.DBObject.ObjectId.ToString) Then
                node.Remove()
                Exit For
            End If
        Next

    End Sub

    <CommandMethod("addData")> _
    Public Sub addData()

        ' get the editor object
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        ' pick entity to add data to!
        Dim getEntityResult As PromptEntityResult = ed.GetEntity("Pick an entity to add an Extension Dictionary to : ")
        ' if all was ok
        If (getEntityResult.Status = PromptStatus.OK) Then
            ' now start a transaction
            Dim trans As Transaction = ed.Document.Database.TransactionManager.StartTransaction
            Try

                ' open the entity for read
                Dim ent As Entity = trans.GetObject(getEntityResult.ObjectId, OpenMode.ForRead)
                ' check to see if there is an extension dictionary available for this entity
                If (ent.ExtensionDictionary.IsNull) Then
                    ' create a new one
                    ' upgrade the open to write
                    ent.UpgradeOpen()
                    ' now create it
                    ent.CreateExtensionDictionary()
                End If
                ' ok must be valid now
                ' open it for read
                Dim extensionDict As DBDictionary = trans.GetObject(ent.ExtensionDictionary, OpenMode.ForRead)

                '  Check to see if the entry we are going to add to the dictionary is 
                ' already there. 
                If (extensionDict.Contains("MyData")) Then

                    ' Get the Object Id of the XRecord 
                    Dim entryId As ObjectId = extensionDict.GetAt("MyData")

                    ' if we are here, then all is ok
                    ' print the data
                    ed.WriteMessage(ControlChars.Lf + "This entity already has data...")
                    ' ok extract the xrecord
                    Dim myXrecord As Xrecord
                    ' read it from the extension dictionary
                    myXrecord = trans.GetObject(entryId, OpenMode.ForRead)
                    ' now print out the values
                    For Each value As TypedValue In myXrecord.Data
                        ed.WriteMessage(ControlChars.Lf + value.TypeCode.ToString() + " . " + value.Value.ToString())
                    Next


                Else
                    ' upgrade to write status
                    extensionDict.UpgradeOpen()

                    ' create a new XRecord
                    Dim myXrecord As New Xrecord
                    ' create the resbuf list
                    Dim data As ResultBuffer = New ResultBuffer(New TypedValue(DxfCode.Int16, 1), _
                                                                New TypedValue(DxfCode.Text, "MyStockData"), _
                                                              New TypedValue(DxfCode.Real, 51.9), _
                                                              New TypedValue(DxfCode.Real, 100.0), _
                                                              New TypedValue(DxfCode.Real, 320.6))
                    ' now add it to the xrecord
                    myXrecord.Data = data

                    ' create the entry
                    extensionDict.SetAt("MyData", myXrecord)
                    ' tell the transaction about the newly created xrecord
                    trans.AddNewlyCreatedDBObject(myXrecord, True)

                    ' now tell our treeview control about the new data
                    ' find the tag we want in the tree
                    ' a good idea to check to see if the palette has been started, if not then it might crash
                    If Not myPalette Is Nothing Then
                        For Each node As Forms.TreeNode In Me.myPalette.TreeView1.Nodes
                            ' if it's the one we want
                            If (node.Tag = ent.ObjectId.ToString()) Then
                                ' add the new data to the treenode
                                Dim childNode As Forms.TreeNode = node.Nodes.Add("Extension Dictionary")
                                ' now add the data
                                For Each value As TypedValue In myXrecord.Data
                                    childNode.Nodes.Add(value.ToString())
                                Next

                                ' all done - break out of the loop
                                Exit For
                            End If
                        Next
                    End If
                End If

                ' all ok, commit it
                trans.Commit()

            Catch ex As Exception
                ' a problem occured, lets print it
                ed.WriteMessage("a problem occured because " + ex.Message)
            Finally
                ' whatever happens we must dispose the transaction
                trans.Dispose()

            End Try

        End If

    End Sub

    <CommandMethod("addDataToNOD")> _
   Public Sub addDataToNOD()

        ' get the editor object
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        ' pick entity to add data to!
        Dim trans As Transaction = ed.Document.Database.TransactionManager.StartTransaction
        Try

            ' open the NOD for read
            Dim nod As DBDictionary = trans.GetObject(ed.Document.Database.NamedObjectsDictionaryId, OpenMode.ForRead)

            ' check to see if our entry is in there
            If (nod.Contains("MyData")) Then
                ' Get the ObjectId of the XRecord    
                Dim entryId As ObjectId = nod.GetAt("MyData")

                ' if we are here, then all is ok
                ' print the data
                ed.WriteMessage(ControlChars.Lf + "This entity already has data...")
                ' ok extract the xrecord
                Dim myXrecord As Xrecord
                ' read it from the NOD dictionary
                myXrecord = trans.GetObject(entryId, OpenMode.ForRead)
                ' now print out the values
                For Each value As TypedValue In myXrecord.Data
                    ed.WriteMessage(ControlChars.Lf + value.TypeCode.ToString() + " . " + value.Value.ToString())
                Next
            Else

                ' upgrade to write status
                nod.UpgradeOpen()

                ' create a new XRecord
                Dim myXrecord As New Xrecord
                ' create the resbuf list
                Dim data As ResultBuffer = New ResultBuffer(New TypedValue(DxfCode.Int16, 1), _
                                                            New TypedValue(DxfCode.Text, "MyCompanyDefaultSettings"), _
                                                            New TypedValue(DxfCode.Real, 51.9), _
                                                            New TypedValue(DxfCode.Real, 100.0), _
                                                            New TypedValue(DxfCode.Real, 320.6))
                ' now add it to the xrecord
                myXrecord.Data = data

                ' create the entry
                nod.SetAt("MyData", myXrecord)
                ' tell the transaction about the newly created xrecord
                trans.AddNewlyCreatedDBObject(myXrecord, True)

            End If

            ' all ok, commit it
            trans.Commit()

        Catch ex As Exception
            ' a problem occurred, lets print it
            ed.WriteMessage("a problem occurred because " + ex.Message)
        Finally
            ' whatever happens we must dispose the transaction
            trans.Dispose()

        End Try

    End Sub
    

    <CommandMethod("addpointmonitor")> _
    Public Sub startMonitor()

        ' get the editor object
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        ' now add the delegate to the events list
        AddHandler ed.PointMonitor, New PointMonitorEventHandler(AddressOf MyPointMonitor)

    End Sub

    Public Sub MyPointMonitor(ByVal sender As Object, ByVal e As PointMonitorEventArgs)
        If e.Context Is Nothing Then
            Return
        End If

        ' first lets check what is under the Cursor
        Dim fullEntPath() As FullSubentityPath = e.Context.GetPickedEntities()
        If (fullEntPath.Length) Then
            ' ok first lets display a ToolTip
            ' start a transaction
            Dim trans As Transaction = Application.DocumentManager.MdiActiveDocument.Database.TransactionManager.StartTransaction
            Try

                ' open the Entity for read
                Dim ent As Entity = trans.GetObject(fullEntPath(0).GetObjectIds(0), OpenMode.ForRead)
                e.AppendToolTipText("The Entity is a " + ent.GetType().ToString())

                ' Make sure the palette is created
                If (myPalette Is Nothing) Then
                    Return
                End If

                ' ok, so if we are over something - then lets highlight it in the palette Window
                ' find the tag we want in the tree
                Dim fontRegular As System.Drawing.Font = New System.Drawing.Font("Microsoft Sans Serif", 8, Drawing.FontStyle.Regular)
                Dim fontBold As System.Drawing.Font = New System.Drawing.Font("Microsoft Sans Serif", 8, Drawing.FontStyle.Bold)

                ' wait until after we have processed the whole tree before we handle the different sized text
                Me.myPalette.TreeView1.SuspendLayout()

                For Each node As Forms.TreeNode In Me.myPalette.TreeView1.Nodes
                    ' if it's the one we want
                    If (node.Tag = ent.ObjectId.ToString()) Then
                        If Not fontBold.Equals(node.NodeFont) Then
                            node.NodeFont = fontBold
                            ' 
                            node.Text = node.Text
                        End If
                    Else
                        If Not fontRegular.Equals(node.NodeFont) Then
                            node.NodeFont = fontRegular
                        End If
                    End If
                Next

                ' now it's time to recalc the layout of the treeview
                Me.myPalette.TreeView1.ResumeLayout()
                Me.myPalette.TreeView1.Refresh()
                Me.myPalette.TreeView1.Update()

                ' all ok, commit it
                trans.Commit()
            Catch ex As Exception

            Finally
                ' whatever happens we must dispose the transaction
                trans.Dispose()

            End Try

        End If

        ' ok, so now lets do something really pointless! space invaders!
        'If (e.Context.History And PointHistoryBits.NotDigitizer) Then
        '    ' this means the mouse has been clicked... so...
        '    ' create a Circle
        '    Dim circle As Circle = New Circle(e.Context.RawPoint, Vector3d.ZAxis, 10)
        '    ' draw it
        '    e.Context.DrawContext.Geometry.Draw(circle)
        '    ' wait for a while
        '    System.Threading.Thread.Sleep(50)
        '    ' draw it
        '    circle.Radius = 20
        '    e.Context.DrawContext.Geometry.Draw(circle)
        '    ' wait for a while
        '    System.Threading.Thread.Sleep(50)
        '    ' draw it
        '    circle.Radius = 40
        '    e.Context.DrawContext.Geometry.Draw(circle)
        '    ' wait for a while
        '    System.Threading.Thread.Sleep(50)
        '    ' draw it
        '    circle.Radius = 80
        '    e.Context.DrawContext.Geometry.Draw(circle)
        '    ' wait for a while
        '    System.Threading.Thread.Sleep(50)

        'End If

    End Sub

    <CommandMethod("newInput")> _
    Public Sub NewInput()

        ' start our input point Monitor    
        ' get the editor object
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        ' now add the delegate to the events list
        AddHandler ed.PointMonitor, New PointMonitorEventHandler(AddressOf MyInputMonitor)
        ed.TurnForcedPickOn()

        ' now pick some point, this emulates a real world input that may be required
        ' pick the center point of the circle
        Dim getPointOptions As PromptPointOptions = New PromptPointOptions("Pick A Point : ")
        Dim getPointResult As PromptPointResult = ed.GetPoint(getPointOptions)
        ' if ok
        If (getPointResult.Status = PromptStatus.OK) Then
            ' do something...
        End If

        ' now remove our point monitor as we are finished With it
        RemoveHandler ed.PointMonitor, AddressOf MyInputMonitor

    End Sub

    Public Sub MyInputMonitor(ByVal sender As Object, ByVal e As PointMonitorEventArgs)

        If e.Context Is Nothing Then
            Return
        End If

        ' first lets check what is under the Cursor
        Dim fullEntPath() As FullSubentityPath = e.Context.GetPickedEntities()
        If (fullEntPath.Length) Then

            ' start a transaction
            Dim trans As Transaction = Application.DocumentManager.MdiActiveDocument.Database.TransactionManager.StartTransaction
            Try

                ' open the Entity for read, it must be derived from Curve
                Dim ent As Curve = trans.GetObject(fullEntPath(0).GetObjectIds(0), OpenMode.ForRead)

                ' ok, so if we are over something - then check to see if it has an extension dictionary
                If (ent.ExtensionDictionary.IsValid) Then

                    ' open it for read
                    Dim extensionDict As DBDictionary = trans.GetObject(ent.ExtensionDictionary, OpenMode.ForRead)

                    ' find the entry
                    Dim entryId As ObjectId = extensionDict.GetAt("MyData")

                    ' if we are here, then all is ok
                    ' extract the xrecord
                    Dim myXrecord As Xrecord
                    ' read it from the extension dictionary
                    myXrecord = trans.GetObject(entryId, OpenMode.ForRead)
                    ' now draw the positions 
                    For Each value As TypedValue In myXrecord.Data
                        ' if the TypeCode is a distance value
                        If (value.TypeCode = DxfCode.Real) Then
                            ' draw some temporary graphics along the Curve to show the distances

                            ' first get the point along the curve
                            Dim pnt As Point3d = ent.GetPointAtDist(value.Value)

                            ' next work out how many pixels are in a unit square - so we can keep the temporary graphics a set size
                            Dim pixels As Point2d = e.Context.DrawContext.Viewport.GetNumPixelsInUnitSquare(pnt)
                            ' setup the constant distances
                            Dim xDist As Double = 10 / pixels.X
                            Dim yDist As Double = 10 / pixels.Y

                            ' then draw the temporary Graphics
                            Dim circle As Circle = New Circle(pnt, Vector3d.ZAxis, xDist)
                            e.Context.DrawContext.Geometry.Draw(circle)

                            ' more temporary graphics
                            Dim text As DBText = New DBText
                            ' always a good idea to set the Database defaults With things like text, dimensions etc
                            text.SetDatabaseDefaults()
                            ' set the position of the text to the same point as the circle, but offset by the radius
                            text.Position = pnt + New Vector3d(xDist, yDist, 0)
                            text.TextString = value.Value.ToString()
                            text.Height = yDist
                            e.Context.DrawContext.Geometry.Draw(text)
                        End If
                    Next
                End If

                ' all ok, commit it
                trans.Commit()
            Catch ex As Exception

            Finally
                ' whatever happens we must dispose the transaction
                trans.Dispose()

            End Try

        End If

    End Sub



    ' The EntityJig class allows you to "jig" one entity at a time. 
    Class MyCircleJig
        Inherits EntityJig

        ' Need two inputs for a circle, the center and the radius. 
        Private centerPoint As Point3d
        Private radius As Double

        ' Because we are going to have 2 inputs, a center point and a radius we need 
        ' to keep track of the input number. (used to determine which value we are getting).
        Private currentInputValue As Integer

        '  We will use a Property to get and set the variable
        Property CurrentInput() As Integer
            Get
                Return currentInputValue
            End Get
            Set(ByVal value As Integer)
                currentInputValue = value
            End Set


        End Property

        ' Create the default constructor. 
        Sub New(ByVal ent As Entity)

            ' Call MyBase.New() and use the ent passed into the constructor. This needs 
            ' to be done because the base class "EntityJig" does not have an accessible
            ' Sub New' that can be called with no arguments
            MyBase.New(ent)

        End Sub


        Protected Overrides Function Sampler(ByVal prompts As Autodesk.AutoCAD.EditorInput.JigPrompts) As Autodesk.AutoCAD.EditorInput.SamplerStatus

            ' For the case use the currentInputValue member variable,
            Select Case (currentInputValue)

                ' Use 0 (zero) for the case. (getting center for the circle)  
                Case 0

                    ' This will be used to test to see if the cursor has moved during the jig. 
                    ' If the user does not change anything, Autocad continually calls the sampler function, 
                    ' and the update function, you will get a flickering effect on the screen.
                    Dim oldPnt As Point3d = centerPoint

                    Dim jigPromptResult As PromptPointResult = prompts.AcquirePoint("Pick center point : ")

                    ' Check the status of the PromptPointResult 
                    If (jigPromptResult.Status = PromptStatus.OK) Then

                        ' Make the centerPoint member variable equal to the Value
                        ' property of the PromptPointResult
                        centerPoint = jigPromptResult.Value

                        ' Check to see if the cursor has moved. 
                        If (oldPnt.DistanceTo(centerPoint) < 0.001) Then
                            ' 14. If we get here then there has not been any change to the location
                            ' Return SamplerStatus.NoChange
                            Return SamplerStatus.NoChange
                        End If
                    End If

                    ' There has been a change in the location so Return the SamplerStatus.OK
                    Return SamplerStatus.OK

                    ' Use 1 for the case. (getting radius for the circle) 
                Case 1

                    '  This will be used to test to see if
                    ' the cursor has moved during jigging for the radius. 
                    Dim oldRadius As Double = radius

                    Dim jigPromptDistanceOpts As New JigPromptDistanceOptions("Pick radius : ")
                    jigPromptDistanceOpts.UseBasePoint = True

                    jigPromptDistanceOpts.BasePoint = centerPoint

                    ' Now we ready to get input. 
                    Dim jigPromptResult As PromptDoubleResult = prompts.AcquireDistance(jigPromptDistanceOpts)


                    ' Check the status of the PromptDoubleResult c
                    If (jigPromptResult.Status = PromptStatus.OK) Then


                        ' Make the radius member varialble equal to the Value
                        ' property of the PromptDoubleResult 
                        radius = jigPromptResult.Value


                        ' Check to see if the radius is too small
                        If (System.Math.Abs(radius) < 0.1) Then
                            ' Arbitrary value to keep the circle from being too small
                            radius = 1
                        End If

                        ' Check to see if the cursor has moved. 
                        If (System.Math.Abs(oldRadius - radius) < 0.001) Then
                            ' If we get here then there has not been any change to the location
                            Return SamplerStatus.NoChange
                        End If
                    End If

                    Return SamplerStatus.OK

            End Select
        End Function


        Protected Overrides Function Update() As Boolean

            ' In this fucntion (Update) for every input, we need to update the entity
            Select Case (currentInputValue)
                ' Use 0 (zero) for the case. (Updating center for the circle) 
                Case 0

                    ' The jig stores the circle as an Entity type. Change it to a circle
                    ' so we can access the properties easily. 
                    CType(Me.Entity, Circle).Center = centerPoint

                    ' Use 1 for the case. (Updating radius for the circle) 
                Case 1

                    ' The jig stores the circle as an Entity type. Change it to a circle
                    ' so we can access the properties easily. 
                    CType(Me.Entity, Circle).Radius = radius

            End Select

        End Function
    End Class


    ' create a command to invoke the EntityJig
    <CommandMethod("circleJig")> _
    Public Sub CircleJig()

        ' Create a new instance of a circle we want to form with the jig
        Dim circle As Circle = New Circle(Point3d.Origin, Vector3d.ZAxis, 10)

        ' Create a new jig. 
        Dim jig As New MyCircleJig(circle)

        ' Now loop for the inputs. 0 will be to position the circle and 1 will 
        ' be to set the radius. 
        For i As Integer = 0 To 1

            ' Set the current input to the loop counter. U
            jig.CurrentInput = i

            ' Get the editor object. 
            Dim ed As Autodesk.AutoCAD.EditorInput.Editor = Application.DocumentManager.MdiActiveDocument.Editor

            ' Invoke the jig. Declare a PromptResult variable and instantite it by 
            ' making it equal to the return of the Drag method of the Editor 
            Dim promptResult As PromptResult = ed.Drag(jig)

            ' Make sure the Status property of the PromptResult variable is ok. U
            If (promptResult.Status = PromptStatus.Cancel Or promptResult.Status = PromptStatus.Error) Then
                ' Some problem occured. Return
                Return
            End If

        Next

        ' once we are finished with the jig, time to add the newly formed circle to the database
        ' get the working database
        Dim dwg As Database = Application.DocumentManager.MdiActiveDocument.Database
        ' now start a transaction
        Dim trans As Transaction = dwg.TransactionManager.StartTransaction
        Try

            ' open the current space for write
            Dim currentSpace As BlockTableRecord = trans.GetObject(dwg.CurrentSpaceId, OpenMode.ForWrite)
            ' add it to the current space
            currentSpace.AppendEntity(circle)
            ' tell the transaction manager about it
            trans.AddNewlyCreatedDBObject(circle, True)

            ' all ok, commit it
            trans.Commit()

        Catch ex As Exception
        Finally
            ' whatever happens we must dispose the transaction
            trans.Dispose()

        End Try

    End Sub



End Class
