' (C) Copyright 2002-2005 by Autodesk, Inc. 
'
' Permission to use, copy, modify, and distribute this software in
' object code form for any purpose and without fee is hereby granted, 
' provided that the above copyright notice appears in all copies and 
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting 
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
'
' Use, duplication, or disclosure by the U.S. Government is subject to 
' restrictions set forth in FAR 52.227-19 (Commercial Computer
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
' (Rights in Technical Data and Computer Software), as applicable.
'


Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.Geometry
Imports Autodesk.AutoCAD.Runtime

' This line is not mandatory, but improves loading performances
<Assembly: CommandClass(GetType(Lab3_Complete_VB.MyCommands))>
Namespace Lab3_Complete_VB

    ' This class is instantiated by AutoCAD for each document when
    ' a command is called by the user the first time in the context
    ' of a given document. In other words, non static data in this class
    ' is implicitly per-document!
    Public Class MyCommands

        <CommandMethod("addAnEnt")>
        Public Sub AddAnEnt()

            ' get the editor object so we can carry out some input
            Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor

            ' first decide what type of entity we want to create
            Dim getWhichEntityOptions As PromptKeywordOptions = New PromptKeywordOptions("Which entity do you want to create? [Circle/Block] : ", "Circle Block")
            ' now input it
            Dim getWhichEntityResult As PromptResult = ed.GetKeywords(getWhichEntityOptions)
            ' if ok
            If (getWhichEntityResult.Status = PromptStatus.OK) Then

                ' test which one is required
                Select Case getWhichEntityResult.StringResult

                    Case "Circle"

                        ' pick the center point of the circle
                        Dim getPointOptions As PromptPointOptions = New PromptPointOptions("Pick Center Point : ")
                        Dim getPointResult As PromptPointResult = ed.GetPoint(getPointOptions)
                        ' if ok
                        If (getPointResult.Status = PromptStatus.OK) Then

                            ' the get the radius
                            Dim getRadiusOptions As PromptDistanceOptions = New PromptDistanceOptions("Pick Radius : ")
                            ' set the start point to the center (the point we just picked)
                            getRadiusOptions.BasePoint = getPointResult.Value
                            ' now tell the input mechanism to actually use the basepoint!
                            getRadiusOptions.UseBasePoint = True
                            ' now get the radius
                            Dim getRadiusResult As PromptDoubleResult = ed.GetDistance(getRadiusOptions)
                            ' if all is ok
                            If (getRadiusResult.Status = PromptStatus.OK) Then

                                ' Begining of Lab3. Create the Circle or block and BlockReference
                                ' 1. Declare a Database variable and instantiate it
                                ' using the Document.Database property of the editor created above. (ed)
                                ' Note: Add the AAutodesk.AutoCAD.DatabaseServices Namespace for Database
                                ' And Transaction Use the Imports keyword (above the class declaration)
                                Dim dwg As Database = ed.Document.Database

                                ' 2. Declare a Transaction variable instantiate it using the 
                                ' TransactionManager.StartTransaction method.
                                Dim trans As Transaction = dwg.TransactionManager.StartTransaction()

                                ' 3. Add a Try, Catch and Finally block. Move the Catch above step 9.
                                ' Put Finally above step 10 and the End Try below step 10.  
                                ' 
                                Try

                                    ' 4. Declare a Circle variable and create it using the New keyword. 
                                    ' Use the the Value property of the PromptPointResult created in
                                    ' Lab2 for the first parameter. For the second parameter (normal)use
                                    ' the Vector3d.ZAxis. Use the Value property of the PromptDoubleResult
                                    ' for the radius.
                                    Dim circle As New Circle(getPointResult.Value, Vector3d.ZAxis, getRadiusResult.Value)

                                    ' 5. Declare a BlockTableRecord variable. Instatiate it using the 
                                    ' GetObject method of the Transaction variable create in step 2. 
                                    ' Use the CurrentSpaceId property of the Database variable created in
                                    ' step 1 for the first parameter. (ObjectId) For the second parameter
                                    ' use OpenMode.ForWrite. We are adding the circle to either ModelSpace
                                    ' or PaperSpace. (the CurrentSpaceId determines this)
                                    Dim btr As BlockTableRecord = trans.GetObject(dwg.CurrentSpaceId, OpenMode.ForWrite)

                                    ' 6. Add the Circle to the BlockTableRecord created in step 5. Use the
                                    ' AppendEntity method and pass in the circle created in step 4.
                                    btr.AppendEntity(circle)

                                    ' 7. Tell the transaction about the new circle so that it can autoclose
                                    ' it. Use the AddNewlyCreatedDBObject method. The first argument is the 
                                    ' circle. Use True for the second argument.
                                    trans.AddNewlyCreatedDBObject(circle, True)

                                    ' 8. Commit the transaction by calling the Commit method. If the code gets
                                    ' this far everything should have worked correctly. 
                                    trans.Commit()

                                Catch ex As Exception
                                    ' 9. Declare an Exception variable for the Catch.  
                                    ' (add "ex as Exception" to the Catch keyword)
                                    ' Use the WriteMessage of the Editor variable (ed) created in Lab2.
                                    ' Use "problem due to " + ex.Message for the Message parameter.
                                    ' If an error occurs the details of the problem will be printed
                                    ' on the AutoCAD command line.
                                    ed.WriteMessage("problem due to " + ex.Message)
                                Finally
                                    ' 10. Dispose the transaction by calling the Dispose method
                                    ' of the Transaction created in step 2. This will be called
                                    'whether an error on not occurred.
                                    trans.Dispose()
                                End Try

                            End If
                        End If

                    Case "Block"

                        ' enter the name of the block
                        Dim blockNameOptions As PromptStringOptions = New PromptStringOptions("Enter name of the Block to create : ")
                        ' no spaces are allowed in a blockname so disable it
                        blockNameOptions.AllowSpaces = False
                        ' get the name
                        Dim blockNameResult As PromptResult = ed.GetString(blockNameOptions)
                        ' if ok
                        If (blockNameResult.Status = PromptStatus.OK) Then

                            ' 11. Declare a Database variable and instantiate it using the
                            ' Document.Database property of the editor created above. (ed)
                            Dim dwg As Database = ed.Document.Database


                            ' 12. Declare a Transaction variable instantiate it using the 
                            ' TransactionManager.StartTransaction method.
                            Dim trans As Transaction = dwg.TransactionManager.StartTransaction

                            ' 13. Add a Try, Catch and Finally block. Move the Catch above step 36.
                            ' Put Finally above step 37 and the End Try below step 37. 
                            Try

                                ' create the new block definition
                                ' 14. Declare a BlockTableRecord variable. Create it using the 
                                ' New keyword.
                                Dim newBlockDef As BlockTableRecord = New BlockTableRecord

                                ' 15. Set the name of the name the block definition. Use the 
                                ' StringResult property of the PromptResult variable above. 
                                ' (created in Lab2) 
                                newBlockDef.Name = blockNameResult.StringResult

                                ' 16. Declare a variable as a BlockTable. Instiate it using the 
                                ' GetObject method of the Transaction Use the BlockTableId property 
                                ' of the Database variable created in step 11 for the first parameter.
                                ' Use OpenMode.ForRead for the second parameter. We are opening for 
                                ' read to check if a block with the name provided by the user already exists.  
                                Dim blockTable As BlockTable = trans.GetObject(dwg.BlockTableId, OpenMode.ForRead)

                                ' 17. Add an If then. Test to see if the BlockTable has a block by
                                ' using the Has method of the variable created in step 16. For the string
                                ' Parameter using the StringResult property of the PromptResult variable above.
                                ' created in Lab2. Check to see if it equals False. Move End if below Step 35
                                If (blockTable.Has(blockNameResult.StringResult) = False) Then

                                    ' 18. The Block with that name does not exist so add it.
                                    ' First make the BlockTable open for write. Do this by calling the 
                                    ' UpgradeOpen() method of the BlockTable. (created in step 16)
                                    blockTable.UpgradeOpen()

                                    ' 19. Add the BlockTableRecord created in step 14. Use the Add method
                                    ' of the BlockTable and pass in the BlockTableRecord.
                                    blockTable.Add(newBlockDef)

                                    ' 20. Tell the transaction about the new block so that it can autoclose
                                    ' it. Use the AddNewlyCreatedDBObject method. The first argument is the 
                                    ' BlockTableRecord. Use True for the second argument.
                                    trans.AddNewlyCreatedDBObject(newBlockDef, True)

                                    ' 21. In the next two steps you add circles to the BlockTableRecord
                                    ' Declare a variable as a Circle and instantiate it using
                                    ' the New Keyword. For the first argument create a New
                                    ' Point3d use (0,0,0) for the second arguement use Vector3d.ZAxis
                                    ' use 10 for the Radius argument.
                                    ' Note: Add the Autodesk.AutoCAD.Geometry Namespace for Point3d
                                    ' Use the Imports keyword (above the class declaration)
                                    Dim circle1 As New Circle(New Point3d(0, 0, 0), Vector3d.ZAxis, 10)

                                    ' 22. Append the circle to the BlockTableRecord. 
                                    ' Use the AppendEntity method pass in the circle from step 21
                                    newBlockDef.AppendEntity(circle1)

                                    ' 23. Now add another circle to the BlockTableRecord
                                    ' Declare a variable as a Circle and instantiate it using
                                    ' the New Keyword. For the first argument create a New
                                    ' Point3d use (20,10,0) for the second arguement use Vector3d.ZAxis
                                    ' use 10 for the Radius argument.
                                    Dim circle2 As New Circle(New Point3d(20, 10, 0), Vector3d.ZAxis, 10)

                                    ' 24. Append the second circle to the BlockTableRecord. 
                                    ' Use the AppendEntity method pass in the circle from step 23
                                    newBlockDef.AppendEntity(circle2)

                                    ' 25. Tell the transaction manager about the new objects so that 
                                    ' the transaction will autoclose them. Call the AddNewlyCreatedDBObject
                                    ' pass in the Circle created in step 21. Do this again for the circle
                                    ' Created in step 23. (use True for the second arguement).
                                    trans.AddNewlyCreatedDBObject(circle1, True)
                                    trans.AddNewlyCreatedDBObject(circle2, True)


                                    ' 26. We have created a new block definition. (BlockTableRecord).
                                    ' Here we will use that Block and add a BlockReference to modelspace.
                                    ' First declare a PromptPointOptions and instantiate it with the New
                                    ' keyword. For the message parameter use "Pick insertion point of BlockRef : "
                                    Dim blockRefPointOptions As PromptPointOptions = New PromptPointOptions("Pick insertion point of BlockRef : ")

                                    ' 27. Declare a PromptPointResult variable. Use the GetPoint method of
                                    ' the Editor created in Lab2 (ed). Pass in the PromptPointOptions created
                                    ' in step 26.
                                    Dim blockRefPointResult As PromptPointResult = ed.GetPoint(blockRefPointOptions)

                                    ' 28. Create an If then and test the Status of the PromptPointResult.
                                    ' Test to see if it is not equal to PromptStatus.OK. 
                                    ' Place the End If below step 30
                                    If (blockRefPointResult.Status <> PromptStatus.OK) Then

                                        ' 29. If we got here then the GetPoint failed. Call the dispose
                                        ' method of the Transaction created in step 11. 
                                        trans.Dispose()
                                        ' 30. Return 
                                        Return
                                    End If

                                    ' 31. Declare a BlockReference variable. Instatiate it with the New keyword
                                    ' Use the Value method of the PromptPointResult for the Position argument. (point3d)
                                    ' Use the ObjectId property of the BlockTableRecord created in Step 14 for the
                                    ' Second parameter.
                                    Dim blockRef As BlockReference = New BlockReference(blockRefPointResult.Value, newBlockDef.ObjectId)

                                    ' 32. Get the current space. (either ModelSpace or PaperSpace. 
                                    ' Declare a BlockTableRecord variable instantiate it using the GetObject
                                    ' method of the Transaction created in step 12. Use the CurrentSpaceId property
                                    ' of the Database created in step 11. Open it for write. (OpenMode.ForWrite)
                                    Dim curSpace As BlockTableRecord = trans.GetObject(dwg.CurrentSpaceId, OpenMode.ForWrite)

                                    ' 33. Use the AppendEntity method of the BlockTableRecord created in step 32
                                    ' and pass in the BlockReference created in step 31.
                                    curSpace.AppendEntity(blockRef)

                                    ' 34. Tell the transaction about the new block reference so that the transaction
                                    ' can autoclose it. Use the AddNewlyCreatedDBObject of the Transaction created in
                                    ' step 12. Pass in the BlockReference. Use True for the second parameter.
                                    trans.AddNewlyCreatedDBObject(blockRef, True)

                                    ' 35. If the code makes it here then all is ok. Commit the transaction by calling 
                                    ' the Commit method
                                    trans.Commit()
                                End If
                            Catch ex As Exception
                                ' 36. Declare an Exception variable for the Catch.  
                                ' (add "ex as Exception" to the Catch keyword)
                                ' Use the WriteMessage of the Editor variable (ed) created in Lab2.
                                ' Use "a problem occured because " + ex.Message for the Message parameter.
                                ' If an error occurs the details of the problem will be printed
                                ' on the AutoCAD command line.
                                ed.WriteMessage("a problem occured because " + ex.Message)
                            Finally
                                ' 37. Dispose the transaction by calling the Dispose method
                                ' of the Transaction created in step 12. This will be called
                                ' whether an error on not occurred.
                                trans.Dispose()

                            End Try

                        End If

                End Select
            End If

        End Sub


    End Class

End Namespace
