﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserControl1
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        TreeView1 = New System.Windows.Forms.TreeView()
        SuspendLayout()
        ' 
        ' TreeView1
        ' 
        TreeView1.Anchor = System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right
        TreeView1.Location = New System.Drawing.Point(52, 44)
        TreeView1.Name = "TreeView1"
        TreeView1.Size = New System.Drawing.Size(211, 115)
        TreeView1.TabIndex = 0
        ' 
        ' UserControl1
        ' 
        AutoScaleDimensions = New System.Drawing.SizeF(8F, 20F)
        AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Controls.Add(TreeView1)
        Name = "UserControl1"
        Size = New System.Drawing.Size(386, 264)
        ResumeLayout(False)
    End Sub

    Friend WithEvents TreeView1 As System.Windows.Forms.TreeView

End Class
