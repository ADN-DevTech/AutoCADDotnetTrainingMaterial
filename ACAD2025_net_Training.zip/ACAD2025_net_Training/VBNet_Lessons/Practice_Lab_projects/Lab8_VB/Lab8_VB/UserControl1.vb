﻿Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.EditorInput
Public Class UserControl1
    ' 38. It’s enough to see that we know when a mouse-move operation takes place. 
    ' We can even go further to tell that the "left" mouse button is currently pressed 
    ' Use an "If Then" statement for the test see if the Left mouse button is being
    ' used: System.Windows.Forms.Control.MouseButtons = System.Windows.Forms.MouseButtons.Left
    ' Put the "End If" beow step 39.


    ' 39. (Ensure a reference to Windowsbase has been added).
    ' This is needed for System.Windows.DependencyObject()
    ' Call the DoDragDrop method of the Application. For the drag source
    ' paramter use the "Me" keyword. For the data paramter use "Me" as well. 
    ' For Allowed effects use System.Windows.Forms.DragDropEffects.All
    ' For the Target paramter use the New statement and a class named "MyDropTarget"
    ' This class is created in steps 40-46. The DropTarget is how our MyDropTarget 
    ' override is hooked up to the mechanism.
End Class

' 40. Here we create a class that will detect when the object is "dropped" 
' in the AutoCAD editor. Add a class to the project called MyDropTarget which
' Inherits from Autodesk.AutoCAD.Windows.DropTarget. (the name needs to be the
' same as used in step 39).
' Note: Put the "End Class" below in steps 46


' 41. Override the OnDrop procedure. (Use Public Overrides) For the parameter
' use "ByVal e As System.Windows.Forms.DragEventArgs"

' 42. Declare a variable as an Editor. Instantiate it by making it equal 
' to Application.DocumentManager.MdiActiveDocument.Editor


' 43. Add a Try Catch block. 
' Note: Put the Catch after step 45 and the End Try after step 46

' 44. Use the Using statement and declare a DocumentLock variable named
' docLock. Instantitate it using:
' Application.DocumentManager.MdiActiveDocument.LockDocument()
' Note: Put the "End Using" after step 45. Creating the variable will
' lock the document and unlock it. 

' 45. Run the AddAnEnt procedure from lab 4. Need to 
' qualify the name with the Class. (adskClass.AddAnEnt())

' 46. add ex as System.Exception to the Catch statement
' Use the Editor created in step 42 to display message to the 
' user. If we get here something went wrong. Use something like
' this for the message parameter:
' "Error Handling OnDrop: " + ex.Message


' Note this is the End of Lab8. Run AutoCAD load the dll and run the 
' Palette command. Drag the label to the drawing area. The AddAnEnd command 
' should start when you drop it.
