﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class myCustomTab
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New System.Windows.Forms.Label()
        TextBox1 = New System.Windows.Forms.TextBox()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New System.Drawing.Point(54, 42)
        Label1.Name = "Label1"
        Label1.Size = New System.Drawing.Size(136, 20)
        Label1.TabIndex = 0
        Label1.Text = "some custom value"
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New System.Drawing.Point(54, 91)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New System.Drawing.Size(125, 27)
        TextBox1.TabIndex = 1
        ' 
        ' myCustomTab
        ' 
        AutoScaleDimensions = New System.Drawing.SizeF(8F, 20F)
        AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Controls.Add(TextBox1)
        Controls.Add(Label1)
        Name = "myCustomTab"
        Size = New System.Drawing.Size(478, 342)
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox

End Class
