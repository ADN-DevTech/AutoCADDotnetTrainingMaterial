﻿' (C) Copyright 2002-2005 by Autodesk, Inc. 
'
' Permission to use, copy, modify, and distribute this software in
' object code form for any purpose and without fee is hereby granted, 
' provided that the above copyright notice appears in all copies and 
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting 
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
'
' Use, duplication, or disclosure by the U.S. Government is subject to 
' restrictions set forth in FAR 52.227-19 (Commercial Computer
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
' (Rights in Technical Data and Computer Software), as applicable.
'

Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Geometry
Imports System.Windows

Imports Autodesk.AutoCAD.Windows

Public Class adskClass

    ' Define command 'helloworld'
    <CommandMethod("helloworld")> _
    Public Sub helloworld()

        ' get the editor object
        Dim ed As Autodesk.AutoCAD.EditorInput.Editor = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor
        ' now write to the command line
        ed.WriteMessage(vbCr + "Hello World")

    End Sub

    <CommandMethod("addAnEnt")> _
    Public Sub AddAnEnt()

        ' get the editor object so we can carry out some input
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor

        ' first decide what type of entity we want to create
        Dim getWhichEntityOptions As PromptKeywordOptions = New PromptKeywordOptions("Which entity do you want to create? [Circle/Block] : ", "Circle Block")
        ' now input it
        Dim getWhichEntityResult As PromptResult = ed.GetKeywords(getWhichEntityOptions)
        ' if ok
        If (getWhichEntityResult.Status = PromptStatus.OK) Then

            ' test which one is required
            Select Case getWhichEntityResult.StringResult

                Case "Circle"

                    ' pick the center point of the circle
                    Dim getPointOptions As PromptPointOptions = New PromptPointOptions("Pick Center Point : ")
                    Dim getPointResult As PromptPointResult = ed.GetPoint(getPointOptions)
                    ' if ok
                    If (getPointResult.Status = PromptStatus.OK) Then

                        ' the get the radius
                        Dim getRadiusOptions As PromptDistanceOptions = New PromptDistanceOptions("Pick Radius : ")
                        ' set the start point to the center (the point we just picked)
                        getRadiusOptions.BasePoint = getPointResult.Value
                        ' now tell the input mechanism to actually use the basepoint!
                        getRadiusOptions.UseBasePoint = True
                        ' now get the radius
                        Dim getRadiusResult As PromptDoubleResult = ed.GetDistance(getRadiusOptions)
                        ' if all is ok
                        If (getRadiusResult.Status = PromptStatus.OK) Then

                            ' need to add the circle to the current space
                            ' get the current working database
                            Dim dwg As Database = ed.Document.Database
                            ' now start a transaction
                            Dim trans As Transaction = dwg.TransactionManager.StartTransaction()
                            Try

                                ' create a new circle
                                Dim circle As New Circle(getPointResult.Value, Vector3d.ZAxis, getRadiusResult.Value)
                                ' open the current space (block table record) for write
                                Dim btr As BlockTableRecord = trans.GetObject(dwg.CurrentSpaceId, OpenMode.ForWrite)
                                ' now the circle to the current space, model space more than likely
                                btr.AppendEntity(circle)
                                ' tell the transaction about the new circle so that it can autoclose it
                                trans.AddNewlyCreatedDBObject(circle, True)
                                ' now commit the transaction
                                trans.Commit()

                            Catch ex As Exception
                                ' ok so we have an exception
                                ed.WriteMessage("problem due to " + ex.Message)
                            Finally
                                ' all done, whether an error on not - dispose the transaction.
                                trans.Dispose()
                            End Try

                        End If
                    End If

                Case "Block"

                    ' enter the name of the block
                    Dim blockNameOptions As PromptStringOptions = New PromptStringOptions("Enter name of the Block to create : ")
                    ' no spaces are allowed in a blockname so disable it
                    blockNameOptions.AllowSpaces = False
                    ' get the name
                    Dim blockNameResult As PromptResult = ed.GetString(blockNameOptions)
                    ' if ok
                    If (blockNameResult.Status = PromptStatus.OK) Then

                        ' lets create the block definition
                        ' get the current drawing
                        Dim dwg As Database = ed.Document.Database
                        ' now start a transaction
                        Dim trans As Transaction = dwg.TransactionManager.StartTransaction
                        Try

                            ' create the new block definition
                            Dim newBlockDef As BlockTableRecord = New BlockTableRecord
                            ' name the block definition
                            newBlockDef.Name = blockNameResult.StringResult

                            ' now add the new block defintion to the block table
                            ' open the blok table for read so we can check to see if the name already exists
                            Dim blockTable As BlockTable = trans.GetObject(dwg.BlockTableId, OpenMode.ForRead)
                            ' check to see if the block already exists
                            If (blockTable.Has(blockNameResult.StringResult) = False) Then
                                ' if it's not there, then we are ok to add it
                                ' but first we need to upgrade the open to write
                                blockTable.UpgradeOpen()
                                blockTable.Add(newBlockDef)
                                ' tell the transaction manager about the new object so that the transaction will autoclose it
                                trans.AddNewlyCreatedDBObject(newBlockDef, True)
                            End If

                            ' now add some objects to the block definition
                            Dim circle1 As New Circle(New Point3d(0, 0, 0), Vector3d.ZAxis, 10)
                            Dim circle2 As New Circle(New Point3d(20, 10, 0), Vector3d.ZAxis, 10)
                            Dim circle3 As New Circle(New Point3d(40, 20, 0), Vector3d.ZAxis, 10)
                            Dim circle4 As New Circle(New Point3d(60, 30, 0), Vector3d.ZAxis, 10)
                            Dim circle5 As New Circle(New Point3d(80, 40, 0), Vector3d.ZAxis, 10)
                            newBlockDef.AppendEntity(circle1)
                            newBlockDef.AppendEntity(circle2)
                            newBlockDef.AppendEntity(circle3)
                            newBlockDef.AppendEntity(circle4)
                            newBlockDef.AppendEntity(circle5)
                            ' tell the transaction manager about the new objects so that the transaction will autoclose it
                            trans.AddNewlyCreatedDBObject(circle1, True)
                            trans.AddNewlyCreatedDBObject(circle2, True)
                            trans.AddNewlyCreatedDBObject(circle3, True)
                            trans.AddNewlyCreatedDBObject(circle4, True)
                            trans.AddNewlyCreatedDBObject(circle5, True)

                            ' now set where it should appear in the current space
                            Dim blockRefPointOptions As PromptPointOptions = New PromptPointOptions("Pick insertion point of Block : ")
                            Dim blockRefPointResult As PromptPointResult = ed.GetPoint(blockRefPointOptions)
                            ' check to see if everything was ok - if not
                            If (blockRefPointResult.Status <> PromptStatus.OK) Then
                                ' dispose of everything that we have done so far and return
                                trans.Dispose()
                                Return
                            End If
                            ' now we have the block defintion in place and the position we need to create the reference to it
                            Dim blockRef As BlockReference = New BlockReference(blockRefPointResult.Value, newBlockDef.ObjectId)
                            ' otherwise add it to the current space, first open the current space for write
                            Dim curSpace As BlockTableRecord = trans.GetObject(dwg.CurrentSpaceId, OpenMode.ForWrite)
                            ' now add the block reference to it
                            curSpace.AppendEntity(blockRef)
                            ' remember to tell the transaction about the new block reference so that the transaction can autoclose it
                            trans.AddNewlyCreatedDBObject(blockRef, True)

                            ' all ok, commit it
                            trans.Commit()

                        Catch ex As Exception
                            ' a problem occured, lets print it
                            ed.WriteMessage("a problem occured because " + ex.Message)
                        Finally
                            ' whatever happens we must dispose the transaction
                            trans.Dispose()

                        End Try

                    End If

            End Select
        End If

    End Sub

    ' 1. Add a Reference to PresentationCore. (Use the .NET tab on 
    ' the Add Reference dialog. This is needed for the PaletteSet
    ' we will declare in step 3.

    ' 2. Use the Imports Statement for namespace Autodesk.AutoCAD.Windows

    ' 3. Declare a PaletteSet variable (global) as a PaletteSet. (It will
    ' only be created once). Add this declaration after AddAnEnt End Sub
    ' from Lab 3. 
    Public myPaletteSet As PaletteSet

    ' 4. Declare a variable as UserControl1. This is the control created
    ' in the steps in the Lab4 document. This control will be housed 
    ' by the PaletteSet created in step 3.
    Public myPalette As UserControl1

    ' 5. Add an new command named palette. Use the CommandMethod
    ' attribute and create the Sub that will run when the command is run
    ' in AutoCAD.
    ' Note: Put the End Sub after step 10.
    <CommandMethod("palette")> _
    Public Sub palette()

        ' 6. Add an "if then" statement and check to see if the 
        ' PaletteSet declared in step 3 is equal to nothing. It will be
        ' Nothing the first time the command is run.
        ' Note: Put the "End If" after step 9
        If (myPaletteSet = Nothing) Then

            ' 7. The PaletteSet is nothing here so we create a a new PaletteSet
            ' with a unique GUID. Use the New keyword. Make the Name Parameter
            ' "My Palette". For the ToolID parameter generate a new GUID.
            ' On the Tools menu select "Create Guid". On the Create GUID
            ' Dialog select "Registry Format" Select New GUID and the copy.
            ' Paste the GUID to use as the New Guid. Replace the curley 
            ' braces with double quotes. (The parameter for New Guid is a string) 
            myPaletteSet = New PaletteSet("My Palette", New Guid("D61D0875-A507-4b73-8B5F-9266BEACD596"))

            ' 8. Instantiate the UserControl1 variable created in 
            ' step 4. Use the New keyword. (New UserControl1) 
            ' This control houses the tree control.
            myPalette = New UserControl1

            ' 9. Add the UserControl to the PaletteSet. Use the Add method
            ' of the PaletteSet instantiated in step 7. Use "Palette1" for the
            ' name parameter and the control instantiated in step 8 for the 
            ' second parameter.
            myPaletteSet.Add("Palette1", myPalette)

        End If

        ' 10. Display the paletteset by making the Visible property of the 
        ' PaletteSet equal to true. The second time the command is run
        ' this is the only code in this procedure that will be processed.
        myPaletteSet.Visible = True

    End Sub


    ' 11. Add a command named "addDBEvents. Use the CommandMethod attribute
    ' and add the procedure that will run when the commmand is run in AutoCAD
    ' Note: Put the End Sub after step 20
    <CommandMethod("addDBEvents")> _
    Public Sub addDBEvents()

        ' 12. use an ""If Then" statement and see if the palette
        ' created in step 4 Is Nothing.
        ' Note: put the "End If" after step 15
        If myPalette Is Nothing Then
            ' 13.  Declare an intantiate a editor object. Use the Editor
            ' property of Application.DocumentManager.MdiActiveDocument
            Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor

            ' 14. Use the WriteMessage method of the Editor variable
            ' created in step 13. Use this for the message parameter
            ' vbCr + "Please call the 'palette' command first"
            ed.WriteMessage(vbCr + "Please call the 'palette' command first")

            ' 15. Exit the Sub
            Exit Sub

        End If

        ' 16. Declare a Database variable and instantiate it by making it 
        ' equal to the Database property of the 
        ' Application.DocumentManager.MdiActiveDocument
        Dim curDwg As Database = Application.DocumentManager.MdiActiveDocument.Database

        ' 17. Use the AddHandler statement to had a Database ObjectAppended
        ' event. Use the ObjectAppended event of the database variable 
        ' created in step 16 for the first parameter (Event). For the second
        ' parameter (Delegate) use the New statement and create an ObjectEventHandler. 
        ' Use the AddressOf statement and the name of a procedure (callback_ObjectAppended)
        ' you will create in step 21. 
        AddHandler curDwg.ObjectAppended, New ObjectEventHandler(AddressOf callback_ObjectAppended)

        ' 18. Use the AddHandler statement to had a Database ObjectErased
        ' event. Use the ObjectErased event of the database variable 
        ' created in step 16 for the first parameter (Event). For the second
        ' parameter (Delegate) use the New statement and create an ObjectErasedEventHandler. 
        ' Use the AddressOf statement and the name of a procedure (callback_ObjectErased)
        ' you will create in step 24. 
        AddHandler curDwg.ObjectErased, New ObjectErasedEventHandler(AddressOf callback_ObjectErased)

        ' 19. Use the AddHandler statement to had a Database ObjectReappended
        ' event. Use the ObjectReappended event of the database variable 
        ' created in step 16 for the first parameter (Event). For the second
        ' parameter (Delegate) use the New statement and create an ObjectEventHandler. 
        ' Use the AddressOf statement and the name of a procedure (callback_ObjectReappended)
        ' you will create in step 32. 
        AddHandler curDwg.ObjectReappended, New ObjectEventHandler(AddressOf callback_ObjectReappended)

        ' 20. Use the AddHandler statement to had a Database ObjectUnappended
        ' event. Use the ObjectUnappended event of the database variable 
        ' created in step 16 for the first parameter (Event). For the second
        ' parameter (Delegate) use the New statement and create an ObjectEventHandler. 
        ' Use the AddressOf statement and the name of a procedure (callback_ObjectUnappended)
        ' you will create in step 35. 
        AddHandler curDwg.ObjectUnappended, New ObjectEventHandler(AddressOf callback_ObjectUnappended)

    End Sub

    ' 21. Create a Private Sub named callback_ObjectAppended. This is the Sub that 
    ' will be called when an Object is Appended to the Database. (The name needs to be
    ' the name used in the Delegate parameter of step 17). The first parameter is an 
    ' object. (Use ByVal and sender as the name of the Object). The second parameter is
    ' an ObjectEventArgs. (Use ByVal and e as the name of the ObjectEventArgs)
    ' Note: Put the End Sub after step 23
    Private Sub callback_ObjectAppended(ByVal sender As Object, ByVal e As ObjectEventArgs)

        ' 22. Declare a TreeNode variable. (System.Windows.Forms.TreeNode). 
        ' Note: You can save some typing by using Imports and importing the namespace
        ' Instantiate it using the Add method of the Nodes property of the TreeView on the 
        ' UserControl created in step 4. Use the ObjectEventArgs passed into the method for 
        ' the string parameter and use the "Type" of DBObject. (e.DBObject.GetType().ToString())
        Dim newNode As System.Windows.Forms.TreeNode = myPalette.TreeView1.Nodes.Add(e.DBObject.GetType().ToString())

        ' 23. Make the Tag property of the node created in step 22 equal to the ObjectId of 
        ' the appended object. This will allow us to record it's ObjectId for recognition in 
        ' other events. Use e.DBObject.ObjectId.ToString()
        newNode.Tag = e.DBObject.ObjectId.ToString()

    End Sub

    ' 24. Create a Private Sub named callback_ObjectErased. This is the Sub that 
    ' will be called when an Object is erased from the Database. (The name needs to be
    ' the name used in the Delegate parameter of step 18). The first parameter is an 
    ' object. (Use ByVal and sender as the name of the Object). The second parameter is
    ' an ObjectErasedEventArgs. (Use ByVal and e as the name of the ObjectErasedEventArgs)
    ' Note: Put the End Sub before step 32
    Private Sub callback_ObjectErased(ByVal sender As Object, ByVal e As ObjectErasedEventArgs)

        ' 25. use an "If Then Else" statement and check the Erased property of the 
        ' ObjectErasedEventArgs passed into the function. (e.Erased) 
        ' Note: Put the "Else" stament before step 30 and the "End If" after step 31
        If e.Erased Then

            ' 26. Here we will search for an object in the treeview control so it can be removed.
            ' Create a For Each statement. Use node for the element name and the type is 
            ' Forms.Treenode. The group paramater is the Nodes in the TreeView.
            ' (myPalette.TreeView1.Nodes)
            ' Note: put the Next statement below step 29. (before the "Else" statement)"
            For Each node As Forms.TreeNode In myPalette.TreeView1.Nodes
                ' 27. Use an "If Then" statement. Test to see if the node Tag is the ObjectId
                ' of the erased Object. Use the DBObject property of the  of the 
                ' ObjectErasedEventArgs passed into the event. (e.DBObject.ObjectId.ToString)
                ' Note: put the "End If" above the "Next" statement added in step 23
                If (node.Tag = e.DBObject.ObjectId.ToString) Then

                    ' 28. Remove the node by calling the Remove method. (The entity was
                    ' erased from the drawing).
                    node.Remove()

                    ' 29. Exit the For loop. (Exit For)
                    Exit For
                End If
            Next

        Else
            ' 30. If this is processed it means that the object was unerased. (e.Erased was false)
            ' Declare a System.Windows.Forms.TreeNode use newNode as the name. Instantiate it by 
            ' using the Add method of the Nodes collection of the TreeView created in previous steps. 
            ' Use the Type of the object for the parameter.
            ' e.DBObject.GetType().ToString()
            Dim newNode As System.Windows.Forms.TreeNode = myPalette.TreeView1.Nodes.Add(e.DBObject.GetType().ToString())

            ' 31. Make the Tag property of the node created in step 30 equal to the ObjectId of 
            ' the unerased object. This will allow us to record it's ObjectId for recognition in 
            ' other events. Use e.DBObject.ObjectId.ToString()
            newNode.Tag = e.DBObject.ObjectId.ToString()
        End If
    End Sub

    ' 32. Create a Private Sub named callback_ObjectReappended. This is the Sub that 
    ' will be called when an Object is ReAppended to the Database. (The name needs to be
    ' the name used in the Delegate parameter of step 19). The first parameter is an 
    ' object. (Use ByVal and sender as the name of the Object). The second parameter is
    ' an ObjectEventArgs. (Use ByVal and e as the name of the ObjectEventArgs)
    ' Note: Put the End Sub after step 34
    Private Sub callback_ObjectReappended(ByVal sender As Object, ByVal e As ObjectEventArgs)

        ' 33. Add the class name of the object to the tree view
        ' Declare a TreeNode variable. (System.Windows.Forms.TreeNode). Instantiate
        ' it using the Add method of the Nodes property of the TreeView on the UserForm1 
        ' created in step 4. Use the ObjectEventArgs passed into the method for the string
        ' parameter and use the "Type" of DBObject. (e.DBObject.GetType().ToString())
        Dim newNode As Forms.TreeNode = myPalette.TreeView1.Nodes.Add(e.DBObject.GetType().ToString())

        ' 34. Record its id for recognition later
        ' Make the Tag property of the node created in step 33 equal to the ObjectId of 
        ' the unerased object. This will allow us to record it's ObjectId for recognition in 
        ' other events. Use e.DBObject.ObjectId.ToString()
        newNode.Tag = e.DBObject.ObjectId.ToString()

    End Sub

    ' 35. Create a Private Sub named callback_ObjectUnappended. This is the Sub that 
    ' will be called when an Object is UnAppended from the Database. (The name needs to be
    ' the name used in the Delegate parameter of step 20). The first parameter is an 
    ' object. (Use ByVal and sender as the name of the Object). The second parameter is
    ' an ObjectEventArgs. (Use ByVal and e as the name of the ObjectEventArgs)
    ' Note: Put the End Sub after step 36
    Private Sub callback_ObjectUnappended(ByVal sender As Object, ByVal e As ObjectEventArgs)

        ' 36. Here we will search for an object in the treeview control so it can be removed.
        ' Create a For Each statement. Use node for the element name and the type is 
        ' Forms.Treenode. The group paramater is the Nodes in the TreeView.
        ' (myPalette.TreeView1.Nodes)
        ' Note: Put the "Next" statement after step 39 
        For Each node As Forms.TreeNode In myPalette.TreeView1.Nodes
            ' 37. Use an "If Then" statement and see if the node is the one we want.
            ' compare the node.Tag to the ObjectId. (use e.DBObject.ObjectId.ToString)
            ' Note: Put the "End If" after step 39 
            If (node.Tag.ToString = e.DBObject.ObjectId.ToString) Then
                ' 38. If we got here then this is the node for the unappended object.
                ' call the Remove method of the node.
                node.Remove()

                ' 39. Exit the For loop. 
                Exit For
            End If
        Next

    End Sub

End Class
