﻿' (C) Copyright 2002-2005 by Autodesk, Inc. 
'
' Permission to use, copy, modify, and distribute this software in
' object code form for any purpose and without fee is hereby granted, 
' provided that the above copyright notice appears in all copies and 
' that both that copyright notice and the limited warranty and
' restricted rights notice below appear in all supporting 
' documentation.
'
' AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
' AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
' MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
' DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
' UNINTERRUPTED OR ERROR FREE.
'
' Use, duplication, or disclosure by the U.S. Government is subject to 
' restrictions set forth in FAR 52.227-19 (Commercial Computer
' Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
' (Rights in Technical Data and Computer Software), as applicable.
'

Imports Autodesk.AutoCAD.Runtime
Imports Autodesk.AutoCAD.ApplicationServices
Imports Autodesk.AutoCAD.EditorInput
Imports Autodesk.AutoCAD.DatabaseServices
Imports Autodesk.AutoCAD.Geometry
Imports System.Windows

Imports Autodesk.AutoCAD.Windows

Public Class adskClass

    ' Define command 'helloworld'
    <CommandMethod("helloworld")> _
    Public Sub helloworld()

        ' get the editor object
        Dim ed As Autodesk.AutoCAD.EditorInput.Editor = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor
        ' now write to the command line
        ed.WriteMessage(vbCr + "Hello World")

    End Sub

    <CommandMethod("addAnEnt")> _
    Public Sub AddAnEnt()

        ' get the editor object so we can carry out some input
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor

        ' first decide what type of entity we want to create
        Dim getWhichEntityOptions As PromptKeywordOptions = New PromptKeywordOptions("Which entity do you want to create? [Circle/Block] : ", "Circle Block")
        ' now input it
        Dim getWhichEntityResult As PromptResult = ed.GetKeywords(getWhichEntityOptions)
        ' if ok
        If (getWhichEntityResult.Status = PromptStatus.OK) Then

            ' test which one is required
            Select Case getWhichEntityResult.StringResult

                Case "Circle"

                    ' pick the center point of the circle
                    Dim getPointOptions As PromptPointOptions = New PromptPointOptions("Pick Center Point : ")
                    Dim getPointResult As PromptPointResult = ed.GetPoint(getPointOptions)
                    ' if ok
                    If (getPointResult.Status = PromptStatus.OK) Then

                        ' the get the radius
                        Dim getRadiusOptions As PromptDistanceOptions = New PromptDistanceOptions("Pick Radius : ")
                        ' set the start point to the center (the point we just picked)
                        getRadiusOptions.BasePoint = getPointResult.Value
                        ' now tell the input mechanism to actually use the basepoint!
                        getRadiusOptions.UseBasePoint = True
                        ' now get the radius
                        Dim getRadiusResult As PromptDoubleResult = ed.GetDistance(getRadiusOptions)
                        ' if all is ok
                        If (getRadiusResult.Status = PromptStatus.OK) Then

                            ' need to add the circle to the current space
                            ' get the current working database
                            Dim dwg As Database = ed.Document.Database
                            ' now start a transaction
                            Dim trans As Transaction = dwg.TransactionManager.StartTransaction()
                            Try

                                ' create a new circle
                                Dim circle As New Circle(getPointResult.Value, Vector3d.ZAxis, getRadiusResult.Value)
                                ' open the current space (block table record) for write
                                Dim btr As BlockTableRecord = trans.GetObject(dwg.CurrentSpaceId, OpenMode.ForWrite)
                                ' now the circle to the current space, model space more than likely
                                btr.AppendEntity(circle)
                                ' tell the transaction about the new circle so that it can autoclose it
                                trans.AddNewlyCreatedDBObject(circle, True)
                                ' now commit the transaction
                                trans.Commit()

                            Catch ex As Exception
                                ' ok so we have an exception
                                ed.WriteMessage("problem due to " + ex.Message)
                            Finally
                                ' all done, whether an error on not - dispose the transaction.
                                trans.Dispose()
                            End Try

                        End If
                    End If

                Case "Block"

                    ' enter the name of the block
                    Dim blockNameOptions As PromptStringOptions = New PromptStringOptions("Enter name of the Block to create : ")
                    ' no spaces are allowed in a blockname so disable it
                    blockNameOptions.AllowSpaces = False
                    ' get the name
                    Dim blockNameResult As PromptResult = ed.GetString(blockNameOptions)
                    ' if ok
                    If (blockNameResult.Status = PromptStatus.OK) Then

                        ' lets create the block definition
                        ' get the current drawing
                        Dim dwg As Database = ed.Document.Database
                        ' now start a transaction
                        Dim trans As Transaction = dwg.TransactionManager.StartTransaction
                        Try

                            ' create the new block definition
                            Dim newBlockDef As BlockTableRecord = New BlockTableRecord
                            ' name the block definition
                            newBlockDef.Name = blockNameResult.StringResult

                            ' now add the new block defintion to the block table
                            ' open the blok table for read so we can check to see if the name already exists
                            Dim blockTable As BlockTable = trans.GetObject(dwg.BlockTableId, OpenMode.ForRead)
                            ' check to see if the block already exists
                            If (blockTable.Has(blockNameResult.StringResult) = False) Then
                                ' if it's not there, then we are ok to add it
                                ' but first we need to upgrade the open to write
                                blockTable.UpgradeOpen()
                                blockTable.Add(newBlockDef)
                                ' tell the transaction manager about the new object so that the transaction will autoclose it
                                trans.AddNewlyCreatedDBObject(newBlockDef, True)
                            End If

                            ' now add some objects to the block definition
                            Dim circle1 As New Circle(New Point3d(0, 0, 0), Vector3d.ZAxis, 10)
                            Dim circle2 As New Circle(New Point3d(20, 10, 0), Vector3d.ZAxis, 10)
                            Dim circle3 As New Circle(New Point3d(40, 20, 0), Vector3d.ZAxis, 10)
                            Dim circle4 As New Circle(New Point3d(60, 30, 0), Vector3d.ZAxis, 10)
                            Dim circle5 As New Circle(New Point3d(80, 40, 0), Vector3d.ZAxis, 10)
                            newBlockDef.AppendEntity(circle1)
                            newBlockDef.AppendEntity(circle2)
                            newBlockDef.AppendEntity(circle3)
                            newBlockDef.AppendEntity(circle4)
                            newBlockDef.AppendEntity(circle5)
                            ' tell the transaction manager about the new objects so that the transaction will autoclose it
                            trans.AddNewlyCreatedDBObject(circle1, True)
                            trans.AddNewlyCreatedDBObject(circle2, True)
                            trans.AddNewlyCreatedDBObject(circle3, True)
                            trans.AddNewlyCreatedDBObject(circle4, True)
                            trans.AddNewlyCreatedDBObject(circle5, True)

                            ' now set where it should appear in the current space
                            Dim blockRefPointOptions As PromptPointOptions = New PromptPointOptions("Pick insertion point of Block : ")
                            Dim blockRefPointResult As PromptPointResult = ed.GetPoint(blockRefPointOptions)
                            ' check to see if everything was ok - if not
                            If (blockRefPointResult.Status <> PromptStatus.OK) Then
                                ' dispose of everything that we have done so far and return
                                trans.Dispose()
                                Return
                            End If
                            ' now we have the block defintion in place and the position we need to create the reference to it
                            Dim blockRef As BlockReference = New BlockReference(blockRefPointResult.Value, newBlockDef.ObjectId)
                            ' otherwise add it to the current space, first open the current space for write
                            Dim curSpace As BlockTableRecord = trans.GetObject(dwg.CurrentSpaceId, OpenMode.ForWrite)
                            ' now add the block reference to it
                            curSpace.AppendEntity(blockRef)
                            ' remember to tell the transaction about the new block reference so that the transaction can autoclose it
                            trans.AddNewlyCreatedDBObject(blockRef, True)

                            ' all ok, commit it
                            trans.Commit()

                        Catch ex As Exception
                            ' a problem occured, lets print it
                            ed.WriteMessage("a problem occured because " + ex.Message)
                        Finally
                            ' whatever happens we must dispose the transaction
                            trans.Dispose()

                        End Try

                    End If

            End Select
        End If

    End Sub

    ' declare a paletteset object, this will only be created once
    Public myPaletteSet As Autodesk.AutoCAD.Windows.PaletteSet
    ' we need a palette which will be housed by the paletteSet
    Public myPalette As UserControl1

    ' palette command
    <CommandMethod("palette")> _
    Public Sub palette()

        ' check to see if it is valid
        If (myPaletteSet = Nothing) Then
            ' create a new palette set, with a unique guid
            myPaletteSet = New Autodesk.AutoCAD.Windows.PaletteSet("My Palette", New Guid("D61D0875-A507-4b73-8B5F-9266BEACD596"))
            ' now create a palette inside, this has our tree control
            myPalette = New UserControl1
            ' now add the palette to the paletteset
            myPaletteSet.Add("Palette1", myPalette)

        End If

        ' now display the paletteset
        myPaletteSet.Visible = True

    End Sub

    <CommandMethod("addDBEvents")> _
    Public Sub addDBEvents()

        ' the palette needs to be created for this
        If myPalette Is Nothing Then
            ' get the editor object
            Dim ed As Autodesk.AutoCAD.EditorInput.Editor = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Editor
            ' now write to the command line
            ed.WriteMessage(vbCr + "Please call the 'palette' command first")
            Exit Sub
        End If

        ' get the current working database
        Dim curDwg As Database = Application.DocumentManager.MdiActiveDocument.Database
        ' add a handlers for what we need
        AddHandler curDwg.ObjectAppended, New ObjectEventHandler(AddressOf callback_ObjectAppended)
        AddHandler curDwg.ObjectErased, New ObjectErasedEventHandler(AddressOf callback_ObjectErased)
        AddHandler curDwg.ObjectReappended, New ObjectEventHandler(AddressOf callback_ObjectReappended)
        AddHandler curDwg.ObjectUnappended, New ObjectEventHandler(AddressOf callback_ObjectUnappended)

    End Sub

    Private Sub callback_ObjectAppended(ByVal sender As Object, ByVal e As ObjectEventArgs)

        ' add the class name of the object to the tree view
        Dim newNode As System.Windows.Forms.TreeNode = myPalette.TreeView1.Nodes.Add(e.DBObject.GetType().ToString())
        ' we need to record its id for recognition later
        newNode.Tag = e.DBObject.ObjectId.ToString()

    End Sub

    Private Sub callback_ObjectErased(ByVal sender As Object, ByVal e As ObjectErasedEventArgs)

        ' if the object was erased
        If e.Erased Then
            ' find the object in the treeview control so we can remove it
            For Each node As Forms.TreeNode In myPalette.TreeView1.Nodes
                ' is this the one we want
                If (node.Tag = e.DBObject.ObjectId.ToString) Then
                    node.Remove()
                    Exit For
                End If
            Next
            ' if the object was unerased
        Else
            ' add the class name of the object to the tree view
            Dim newNode As System.Windows.Forms.TreeNode = myPalette.TreeView1.Nodes.Add(e.DBObject.GetType().ToString())
            ' we need to record its id for recognition later
            newNode.Tag = e.DBObject.ObjectId.ToString()
        End If
    End Sub
    Private Sub callback_ObjectReappended(ByVal sender As Object, ByVal e As ObjectEventArgs)

        ' add the class name of the object to the tree view
        Dim newNode As Forms.TreeNode = myPalette.TreeView1.Nodes.Add(e.DBObject.GetType().ToString())
        ' we need to record its id for recognition later
        newNode.Tag = e.DBObject.ObjectId.ToString()

    End Sub

    Private Sub callback_ObjectUnappended(ByVal sender As Object, ByVal e As ObjectEventArgs)

        ' find the object in the treeview control so we can remove it
        For Each node As Forms.TreeNode In myPalette.TreeView1.Nodes
            ' is this the one we want
            If (node.Tag = e.DBObject.ObjectId.ToString) Then
                node.Remove()
                Exit For
            End If
        Next

    End Sub


    <CommandMethod("addData")> _
    Public Sub addData()

        ' get the editor object
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        ' pick entity to add data to!
        Dim getEntityResult As PromptEntityResult = ed.GetEntity("Pick an entity to add an Extension Dictionary to : ")
        ' if all was ok
        If (getEntityResult.Status = PromptStatus.OK) Then
            ' now start a transaction
            Dim trans As Transaction = ed.Document.Database.TransactionManager.StartTransaction
            Try

                ' open the entity for read
                Dim ent As Entity = trans.GetObject(getEntityResult.ObjectId, OpenMode.ForRead)
                ' check to see if there is an extension dictionary available for this entity
                If (ent.ExtensionDictionary.IsNull) Then
                    ' create a new one
                    ' upgrade the open to write
                    ent.UpgradeOpen()
                    ' now create it
                    ent.CreateExtensionDictionary()
                End If
                ' ok must be valid now
                ' open it for read
                Dim extensionDict As DBDictionary = trans.GetObject(ent.ExtensionDictionary, OpenMode.ForRead)

                Try
                    ' check to see if our entry is in there, excpetion will be thrown if not so process that
                    ' condition in the catch
                    Dim entryId As ObjectId = extensionDict.GetAt("MyData")

                    ' if we are here, then all is ok
                    ' print the data
                    ed.WriteMessage(ControlChars.Lf + "This entity already has data...")
                    ' ok extract the xrecord
                    Dim myXrecord As Xrecord
                    ' read it from the extension dictionary
                    myXrecord = trans.GetObject(entryId, OpenMode.ForRead)
                    ' now print out the values
                    For Each value As TypedValue In myXrecord.Data
                        ed.WriteMessage(ControlChars.Lf + value.TypeCode.ToString() + " . " + value.Value.ToString())
                    Next

                Catch
                    ' upgrade to write status
                    extensionDict.UpgradeOpen()

                    ' create a new XRecord
                    Dim myXrecord As New Xrecord
                    ' create the resbuf list
                    Dim data As ResultBuffer = New ResultBuffer(New TypedValue(DxfCode.Int16, 1), _
                                                                New TypedValue(DxfCode.Text, "MyStockData"), _
                                                              New TypedValue(DxfCode.Real, 51.9), _
                                                              New TypedValue(DxfCode.Real, 100.0), _
                                                              New TypedValue(DxfCode.Real, 320.6))
                    ' now add it to the xrecord
                    myXrecord.Data = data

                    ' create the entry
                    extensionDict.SetAt("MyData", myXrecord)
                    ' tell the transaction about the newly created xrecord
                    trans.AddNewlyCreatedDBObject(myXrecord, True)

                    ' now tell our treeview control about the new data
                    ' find the tag we want in the tree
                    ' a good idea to check to see if the palette has been started, if not then it might crash
                    If Not myPalette Is Nothing Then
                        For Each node As Forms.TreeNode In Me.myPalette.TreeView1.Nodes
                            ' if it's the one we want
                            If (node.Tag = ent.ObjectId.ToString()) Then
                                ' add the new data to the treenode
                                Dim childNode As Forms.TreeNode = node.Nodes.Add("Extension Dictionary")
                                ' now add the data
                                For Each value As TypedValue In myXrecord.Data
                                    childNode.Nodes.Add(value.ToString())
                                Next

                                ' all done - break out of the loop
                                Exit For
                            End If
                        Next
                    End If
                End Try

                ' all ok, commit it
                trans.Commit()

            Catch ex As Exception
                ' a problem occured, lets print it
                ed.WriteMessage("a problem occured because " + ex.Message)
            Finally
                ' whatever happens we must dispose the transaction
                trans.Dispose()

            End Try

        End If

    End Sub

    <CommandMethod("addDataToNOD")> _
    Public Sub addDataToNOD()

        ' get the editor object
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        ' pick entity to add data to!
        Dim trans As Transaction = ed.Document.Database.TransactionManager.StartTransaction
        Try

            ' open the NOD for read
            Dim nod As DBDictionary = trans.GetObject(ed.Document.Database.NamedObjectsDictionaryId, OpenMode.ForRead)

            Try
                ' check to see if our entry is in there, excpetion will be thrown if not so process that
                ' condition in the catch
                Dim entryId As ObjectId = nod.GetAt("MyData")

                ' if we are here, then all is ok
                ' print the data
                ed.WriteMessage(ControlChars.Lf + "This entity already has data...")
                ' ok extract the xrecord
                Dim myXrecord As Xrecord
                ' read it from the NOD dictionary
                myXrecord = trans.GetObject(entryId, OpenMode.ForRead)
                ' now print out the values
                For Each value As TypedValue In myXrecord.Data
                    ed.WriteMessage(ControlChars.Lf + value.TypeCode.ToString() + " . " + value.Value.ToString())
                Next

            Catch
                ' upgrade to write status
                nod.UpgradeOpen()

                ' create a new XRecord
                Dim myXrecord As New Xrecord
                ' create the resbuf list
                Dim data As ResultBuffer = New ResultBuffer(New TypedValue(DxfCode.Int16, 1), _
                                                            New TypedValue(DxfCode.Text, "MyCompanyDefaultSettings"), _
                                                            New TypedValue(DxfCode.Real, 51.9), _
                                                            New TypedValue(DxfCode.Real, 100.0), _
                                                            New TypedValue(DxfCode.Real, 320.6))
                ' now add it to the xrecord
                myXrecord.Data = data

                ' create the entry
                nod.SetAt("MyData", myXrecord)
                ' tell the transaction about the newly created xrecord
                trans.AddNewlyCreatedDBObject(myXrecord, True)

            End Try

            ' all ok, commit it
            trans.Commit()

        Catch ex As Exception
            ' a problem occurred, lets print it
            ed.WriteMessage("a problem occurred because " + ex.Message)
        Finally
            ' whatever happens we must dispose the transaction
            trans.Dispose()

        End Try

    End Sub


    ' Start of Lab6
    ' Note: In step 10 you add a tooltip to the PointMonitor. In the first 
    ' release of AutoCAD 2012 there is a problem and Tooltips are not displaying. 
    ' unless the setting for ROLLOVERTIPS = 0
    ' This should be fixed in the first service pack. Also in AutoCAD 2012 you 
    ' may get an assert when hovering over entities after adding the PointMonitor.
    ' (just ignore it) This problem has been reported to AutoCAD engineering.

    ' 1. Use the CommandMethod attribute and create a command named "addpointmonitor"
    ' name the Sub something like startMonitor
    ' Note: put the "End Sub" after step 3

    ' 2. Declare an Editor variable named ed. Instantiate it using the Editor property
    ' of the Application.DocumentManager.MdiActiveDocument

    ' 3. Use the AddHandler statement to had a Editor PointMonitor event
    ' Use the PointMonitor event of the Editor variable 
    ' created in step 2 for the first parameter (Event). For the second
    ' parameter (Delegate) use the New statement and create an 
    ' PointMonitorEventHandler use the AddressOf statement and the name 
    ' of a procedure (MyPointMonitor) The procedure will be created in step 4. 


    ' 4. Create a Public Sub named MyPointMonitor. This is the Sub that 
    ' will be called everytime the mouse moves. (The name needs to be
    ' the name used in the Delegate parameter of step 3). The first parameter is an 
    ' object. (Use ByVal and sender as the name of the Object). The second parameter is
    ' a PointMonitorEventArgs. (Use ByVal and e as the name of the PointMonitorEventArgs)
    ' Note: Put the End Sub after step 27

    ' 5. Declare an array of the Type FullSubentityPath type. For the name
    ' of the array use something like fullEntPath. Instantiate it by 
    ' making it equal to the GetPickedEntities method of the Context
    ' property of the PointMonitorEventArgs passed into the Sub

    ' 6. Use an "If Then" statement and test the Length property of the array
    ' created in step 5
    ' Note: Put the "End If" after step 27


    ' 7. Declare a variable named trans as a Transaction. Instantiate it by makine it 
    ' equal to the return of the StartTransaction method of the TransactionManager 
    ' of the current database. 
    ' Application.DocumentManager.MdiActiveDocument.Database.TransactionManager.StartTransaction

    ' 8. Create a Try Catch block. 
    ' Note: Put the Catch after step 25 and the Finally statements after step 26
    ' Put the End Try after step 27


    ' 9. Declare a variable as an Entity. Instantiate it using the 
    ' GetObject method of the transaction created in step 7. For
    ' the ObjectId parameter use the first element in GetObjectIds(0)
    ' of the zero element in the array of FullSubentityPath created in
    ' step 5 open the Entity for read

    ' 10. Add a tooltip by using the AppendToolTipText method of the 
    ' PointMonitorEventArgs passed into the Sub. Use something like this for 
    ' string argument:
    ' "The Entity is a " + ent.GetType().ToString()

    ' 11. Use an "If Then" and Check that the palette (myPalette) has 
    'been created. (Is Nothing) If it does not exist return. 

    ' 12. The following steps will make the text of the entry for a DBEntity
    ' in the palette created in Lab4 Bold. Declare a variable named fontRegular
    ' as a System.Drawing.Font. Instantiate it by making it equal to a New
    ' System.Drawing.Font. For the arguments use the following:
    ' "Microsoft Sans Serif", 8, Drawing.FontStyle.Regular

    ' 13. Declare a variable named fontBold as a System.Drawing.Font. 
    ' Instantiate it by making it equal to a New
    ' System.Drawing.Font. For the arguments use the following:
    ' "Microsoft Sans Serif", 8, Drawing.FontStyle.Bold


    ' 14. Use the SuspendLayout() method of the TreeView created in Lab4 to 
    ' wait until after the steps below are processed. Use the "Me" Keyword to
    ' get to the Palette (myPalette) with the TreeView.

    ' 15. Here we will search for an object in the treeview control so the font 
    ' can be chaged to bold.
    ' Create a For Each statement. Use node for the element name and the type is 
    ' Forms.Treenode. The group paramater is the Nodes in the TreeView.
    ' (myPalette.TreeView1.Nodes)
    ' Note: put the Next statement below step 21. 
    ' (In this For Each if the cursor is over an entity and the entity is 
    ' an entry in the TreeView it will be highlighted.

    ' 16. use an "If Else Then" and see if the Tag property of the node
    ' is equal to the ObjectId of the entity declared in step 9. 
    ' (Use ToString for the comparison)
    ' Note: put the "Else" after step 19
    ' Put the "End IF" after step 21. 

    ' 17. If we get here then the node is the one we want.
    ' Use "If Not" and use the Equals method of the 
    ' System.Drawing.Font variable created in step 12. For 
    ' the Object parameter use the NodeFont property of the node.
    ' Note: Put the "End If" after step 19

    ' 18. Make the NodeFont property of the node equal to the
    ' System.Drawing.Font variable created in step 13.

    ' 19. Make the Text property of the node equal to the 
    ' node.Text property.

    ' 20. If we get here then the node is not the node we want.
    ' Use "If Not" and use the Equals method of the 
    ' System.Drawing.Font variable created in step 12. For 
    ' the Object parameter use the NodeFont property of the node.
    ' Note: Put the "End If" after step 21.


    ' 21. Make the NodeFont property of the node equal to the
    ' System.Drawing.Font variable created in step 12


    ' 22. Now it's time to recalc the layout of the treeview. Use the 
    ' ResumeLayout() method of the TreeView. Use the "Me" Keyword to
    ' get to the Palette with the TreeView.

    ' 23. Refresh the TreView with the Refresh method() of the TreeView.

    ' 24. Update the TreView with the Update method() of the TreeView.

    ' 25. All is ok if we get here so Commit the transaction created in 
    ' step 7.

    ' 26. Use the WriteMessgae of the editor to put the text of
    ' the exception on the AutoCAD command line.
    ' Application.DocumentManager.MdiActiveDocument.Editor



    ' 27. Whatever happens we must dispose the transaction. (This is 
    ' in the Finally block). Use the Dispose method of the 
    ' transaction created in step 7.
    ' Note: continue to step 28 in the NewInput function. You could also build and
    ' test the addPointmonitor command before completing the following steps.


    <CommandMethod("newInput")> _
    Public Sub NewInput()

        ' start our input point Monitor    
        ' get the editor object
        Dim ed As Editor = Application.DocumentManager.MdiActiveDocument.Editor
        ' now add the delegate to the events list
        AddHandler ed.PointMonitor, New PointMonitorEventHandler(AddressOf MyInputMonitor)

        ' 28. Need to enable the AutoCAD input event mechanism to do a pick under the prevailing
        ' pick aperture on all digitizer events, regardless of whether a point is being acquired 
        ' or whether any OSNAP modes are currently active. Use the TurnForcedPickOn method
        ' of the Editor created above. "ed"


        ' 29. Here we are going to ask the user to pick a point. Declare a variable as a 
        ' PromptPointOptions. Instantiate it by creating a New PromptPointOptions 
        ' for the Message parameter using something like "Pick A Point : "

        ' 30. Declare a variable as a PromptPointResult. Instantiate it using the GetPoint
        ' method of the editor created above. "ed". Pass in the PromptPointOptions created
        ' in step 28.

        ' if ok
        'If (getPointResult.Status = PromptStatus.OK) Then
        '    ' do something...
        'End If

        ' 31. Now remove our point monitor as we are finished With it.
        ' Use RemoveHandler for the object use the PointMonitor property of the
        ' Editor created above. "ed". For the Delegate argument use AddressOf and 
        ' the name of the callback function. "MyInputMonitor"
        ' Continue to step 31 in the MyInputMonitor Sub.

    End Sub

    Public Sub MyInputMonitor(ByVal sender As Object, ByVal e As PointMonitorEventArgs)

        ' first lets check what is under the Cursor
        Dim fullEntPath() As FullSubentityPath = e.Context.GetPickedEntities()
        If (fullEntPath.Length) Then

            ' start a transaction
            Dim trans As Transaction = Application.DocumentManager.MdiActiveDocument.Database.TransactionManager.StartTransaction
            Try

                ' open the Entity for read, it must be derived from Curve
                Dim ent As Curve = trans.GetObject(fullEntPath(0).GetObjectIds(0), OpenMode.ForRead)

                ' ok, so if we are over something - then check to see if it has an extension dictionary
                If (ent.ExtensionDictionary.IsValid) Then

                    ' open it for read
                    Dim extensionDict As DBDictionary = trans.GetObject(ent.ExtensionDictionary, OpenMode.ForRead)

                    ' find the entry
                    Dim entryId As ObjectId = extensionDict.GetAt("MyData")

                    ' if we are here, then all is ok
                    ' extract the xrecord
                    Dim myXrecord As Xrecord
                    ' read it from the extension dictionary
                    myXrecord = trans.GetObject(entryId, OpenMode.ForRead)


                    ' 32. ' We will draw temporary graphics at certain positions along the entity
                    ' Create a "For Each" loop. For the element use a TypedValue
                    ' named myTypeVal. For the group use the Data property of the Xrecord
                    ' instantiated above. "myXrecord".
                    ' Note" put "Next" after step 45.

                    ' 33. Use an "If Then" and see if the TypeCode of the TypedValue
                    ' is a real. (Use DxfCode.Real as the test).
                    ' Note: Put the "End If" after step 45.


                    ' 34. To locate the temporary graphics along the Curve 
                    ' to show the distances we need to get the point along the curve.
                    ' Declare a vaiable as a Point3d object. Instantiate it using 
                    ' the GetPointAtDist method of the ent instantatied above. "ent"
                    ' For the Value parameter using the Value property of the TypedValue

                    ' 35. We need to work out how many pixels are in a unit square
                    ' so we can keep the temporary graphics a set size regardless of
                    ' the zoom scale. Declare a variable as a Point2d name it something
                    ' like "pixels". Instantiate it using the GetNumPixelsInUnitSquare method
                    ' of the current Viewport. (Pass in the Point3d created in step 34).
                    'Use: e.Context.DrawContext.Viewport.GetNumPixelsInUnitSquare()


                    ' 36. We need some constant distances. Declare a variable as a Double
                    ' named something like "xDist". make it equal to 10 divided by the 
                    ' X property of the Point2d variable created in step 35. 

                    ' 37. Declare a variable as a Double named something like "yDist". 
                    ' make it equal to 10 divided by the Y property of the Point2d variable
                    ' created in step 35. 


                    ' 38. Draw the temporary Graphics. Declare a variable as a Circle
                    ' instantiate is by creating a New Circle. Use the Point3d variable
                    ' created in step 33 for the for the center. For the normal use 
                    ' Vector3d.ZAxis. For the radius use the double from step 36. 

                    ' 39. Use the Draw method to display the circle. (Pass in the Circle). 
                    ' Use:  e.Context.DrawContext.Geometry.Draw()


                    ' 40. Here we will add more temporary graphics. (text). Declare
                    ' a variable as DBText. Instantiate it by creating New DBText.

                    ' 41. Always a good idea to set the Database defaults With things like 
                    ' text, dimensions etc. Use the SetDatabaseDefaults method of the DBText
                    ' from step 40

                    ' 42. Set the position of the text to the same point as the circle, 
                    ' but offset by the radius. Use the Position property and make it
                    ' equal to the Point3d created in step 34 plus a New Vector3d. For
                    ' the X parameter use the Double from step 36. For the Y parameter use 
                    ' the Double from step 37. For Z just use zero.

                    ' 43. Use the data from the Xrecord for the text. Use the TextString
                    ' property of the DBText created in step 49. Make it equal to the 
                    ' Value of the TypedValue. (use ToString)

                    ' 44. Make the Height of the DBText equal to the Double created in 
                    ' step 36

                    ' 45. Use the Draw method to display the text. (Pass in the DBText). 
                    ' Use:  e.Context.DrawContext.Geometry.Draw()
                    ' Note: The backgound color may impact the display of the temporary 
                    ' text. (it displays as white in this example, so may need to change
                    ' the background color to see it, or change the color of the DBText)

                    ' End of Lab6


                End If

                ' all ok, commit it
                trans.Commit()
            Catch ex As Exception

            Finally
                ' whatever happens we must dispose the transaction
                trans.Dispose()

            End Try

        End If

    End Sub



End Class